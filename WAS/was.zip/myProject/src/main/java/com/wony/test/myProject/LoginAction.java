package com.wony.test.myProject;

import com.opensymphony.xwork2.ActionSupport;

public class LoginAction {
    private static final String SUCCESS = "success";
    private static final String ERROR = "error";
	private UserDAO userDAO;
    private User user;
     
    public void setUserDAO(UserDAO userDAO) {
        this.userDAO = userDAO;
    }
    
    public UserDAO getUserDAO(){
    	return userDAO;
    }
 
    public void setUser(User user) {
        this.user = user;
    }
     
    public User getUser() {
        return user;
    }
 
    public String execute() {
        if (userDAO.checkLogin(user)) {
            return SUCCESS;
        }         
        return ERROR;
    }
}
