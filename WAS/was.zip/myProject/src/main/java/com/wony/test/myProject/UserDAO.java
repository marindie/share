package com.wony.test.myProject;

public class UserDAO {
    public boolean checkLogin(User user){
    		return user.getUsername().equals("admin") && user.getPassword().equals("nimda");
    }
}