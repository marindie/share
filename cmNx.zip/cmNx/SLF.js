//==============================================================================
//
//  Copyright 2021 TOBESOFT Co., Ltd.
//  All Rights Reserved.
//
//  NOTICE: TOBESOFT permits you to use, modify, and distribute this file 
//          in accordance with the terms of the license agreement accompanying it.
//
//  Readme URL: http://www.nexacro.com/legal/license/tobesoft/ko/NexacroN-public-license-readme-1.1.html
//
//==============================================================================

const SLF = {
	screenWidth : system.getScreenResolution(1).split(" ")[0]
	, screenHeight : system.getScreenResolution(1).split(" ")[1]
	, app : function(){
		return nexacro.getApplication();
	}, getCenterOfComp : function(width, height){
		//모니터 해상도 정보 Ex. 1980 1024
		var screenInfo = system.getScreenResolution(1).split(" ");
		var nLeft = (nexacro.toNumber(screenInfo[0]) - width)/2;
		var nTop = (nexacro.toNumber(screenInfo[1]) - height)/2;		
		var info = {
			top : nTop
			, left : nLeft
		}
		return info
	}, newDs : function(obj, colArr, dsId){
		var ds = new Dataset;
		if(Array.isArray(colArr)){
			colArr.forEach(function(item,index,arr2){
				ds.addColumn(item, 'string', '255');
			});
			obj.addChild(dsId, ds);
			return ds;
		}
		return null;
	}, openForm : function(sID, sName, sURL){
		if(sURL.length <= 0) return;

		var objApp = nexacro.getApplication();
		var nCnt = objApp.gds_openForm.getRowCount();
		if(nCnt >= 10){
			objApp.alert("The Form can be opened up to 10.");
			return false;
		}
		
		//업무영역 Size, application.av_WorkFrame --> WorkFrame Path
		var nWidth  = objApp.av_WorkFrame.getOffsetWidth();
		var nHeight = objApp.av_WorkFrame.getOffsetHeight();

		//화면 ID 생성("FORM_" + 메뉴ID + random)
		var sFormID = "FORM_" + sID + "_" + parseInt(Math.random() * 1000);

		var objChildFrame = new ChildFrame();	
		objChildFrame.init(sFormID, 0, 0, nWidth, nHeight);

		objApp.av_WorkFrame.addChild(sFormID, objChildFrame);
		
		objChildFrame.set_resizable(true);
		objChildFrame.set_openstatus("maximize");
		objChildFrame.set_border("1px solid #5d6468");

		var oParam = { FORM_ID : sFormID, 
					   MENU_ID : sID, 
					   MENU_NM : sName, 
					   FORM_URL : sURL,
					   FORM_TYPE : "ADD" };	
		
		//Work Frame에 필요한 정보 Set
		objChildFrame.param = oParam;
		objChildFrame.set_formurl("FrameBase::WorkFrame.xfdl");	
		objChildFrame.show();

		//열린 화면 Tab 생성
		nexacro.getApplication().mainframe.VFrameSet0.HFrameSet0.VFrameSet1.MDIFrame.form.fn_addTab(oParam);
	}
	
}
