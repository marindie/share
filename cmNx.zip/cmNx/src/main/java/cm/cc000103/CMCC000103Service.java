package cm.cc000103;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service("sCMCC000103Service")
public class CMCC000103Service{
	private Logger logger = LoggerFactory.getLogger(CMCC000103Service.class);
  
    @Resource(name = "mCMCC000103Mapper")
    private CMCC000103Mapper mCMCC000103Mapper;
    
    public List<Map<String,Object>> getCoAmt(Map<String,String> searchInfo) {
    	return mCMCC000103Mapper.getCoAmt(searchInfo);
    }

    public List<Map<String,Object>> getCoAmtSum(Map<String,String> searchInfo) {
    	return mCMCC000103Mapper.getCoAmtSum(searchInfo);
    }
    
    public List<Map<String,Object>> getDailyAmt(Map<String,String> searchInfo) {
    	return mCMCC000103Mapper.getDailyAmt(searchInfo);
    }    
}
