package cm.cc000103;

import java.util.List;
import java.util.Map;

import egovframework.rte.psl.dataaccess.mapper.Mapper;

@Mapper("mCMCC000103Mapper")
public interface CMCC000103Mapper {
	List<Map<String,Object>> getCoAmt(Map<String,String> searchInfo);
	
	List<Map<String,Object>> getCoAmtSum(Map<String,String> searchInfo);
	
	List<Map<String,Object>> getDailyAmt(Map<String,String> searchInfo);
}
