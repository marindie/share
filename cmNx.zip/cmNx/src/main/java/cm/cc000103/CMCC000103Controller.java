package cm.cc000103;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nexacro.uiadapter.spring.core.annotation.ParamDataSet;
import com.nexacro.uiadapter.spring.core.data.NexacroResult;

@Controller
@RequestMapping(value = "/CMCC00103")
public class CMCC000103Controller {
  private Logger logger = LoggerFactory.getLogger(CMCC000103Controller.class);
  
    @Resource(name = "sCMCC000103Service")
    private CMCC000103Service sCMCC000103Service;
    
    @RequestMapping(value = "/getCoAmt.nx")
    public NexacroResult getCoAmt(@ParamDataSet(name = "dsSearch", required = false) Map<String,String> dsSearch) {
      
    	logger.debug("getLoginInfo dsSearch >>> " + dsSearch);

        List<Map<String, Object>> getLoginInfo = sCMCC000103Service.getCoAmt(dsSearch);

        NexacroResult result = new NexacroResult();
        result.addDataSet("dsRet", getLoginInfo);

        return result;
    }
    
    @RequestMapping(value = "/getCoAmtSum.nx")
    public NexacroResult getCoAmtSum(@ParamDataSet(name = "dsSearch", required = false) Map<String,String> dsSearch) {
      
    	logger.debug("getLeftMenuInfo dsSearch >>> " + dsSearch);

        List<Map<String, Object>> getLeftMenuInfo = sCMCC000103Service.getCoAmtSum(dsSearch);

        NexacroResult result = new NexacroResult();
        result.addDataSet("dsRet", getLeftMenuInfo);

        return result;
    }
    
    @RequestMapping(value = "/getDailyAmt.nx")
    public NexacroResult getDailyAmt(@ParamDataSet(name = "dsSearch", required = false) Map<String,String> dsSearch) {
      
    	logger.debug("getLeftMenuInfo dsSearch >>> " + dsSearch);

        List<Map<String, Object>> getLeftMenuInfo = sCMCC000103Service.getDailyAmt(dsSearch);

        NexacroResult result = new NexacroResult();
        result.addDataSet("dsRet", getLeftMenuInfo);

        return result;
    }        
}
