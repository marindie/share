package cm.sample;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nexacro.uiadapter.spring.core.annotation.ParamDataSet;
import com.nexacro.uiadapter.spring.core.data.NexacroResult;

@Controller
public class SampleController {
  private Logger logger = LoggerFactory.getLogger(SampleController.class);
  
    @Resource(name = "sampleService")
    private SampleService testService;
    
    @RequestMapping(value = "/sample01.nx")
    public NexacroResult sample01(@ParamDataSet(name = "dsSearch", required = false) Map<String,String> dsSearch) {
      
    	logger.debug("sample01 ds_search >>> " + dsSearch);

        List<Map<String, Object>> sampleList = new ArrayList<Map<String,Object>>();
        
        sampleList = testService.selectSampleList01(dsSearch);

        NexacroResult result = new NexacroResult();
        result.addDataSet("output1", sampleList);

        return result;
    }    
}
