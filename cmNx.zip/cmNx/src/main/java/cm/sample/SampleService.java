package cm.sample;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service("sampleService")
public class SampleService{
	  private Logger logger = LoggerFactory.getLogger(SampleService.class);
	  
	    @Resource(name = "sampleMapper")
	    private SampleMapper sampleMapper;
	    
	    public List<Map<String,Object>> selectSampleList(Map<String,String> searchInfo) {
	    	return sampleMapper.selectSampleList(searchInfo);
	    }

		public List<Map<String, Object>> selectSampleList01(Map<String, String> searchInfo) {
			return sampleMapper.selectSampleList01(searchInfo);
		}
}
