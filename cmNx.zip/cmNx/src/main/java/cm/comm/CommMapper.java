package cm.comm;

import java.util.List;
import java.util.Map;

import egovframework.rte.psl.dataaccess.mapper.Mapper;

@Mapper("commMapper")
public interface CommMapper {
	List<Map<String,Object>> getLoginInfo(Map<String,String> searchInfo);
	List<Map<String,Object>> getLeftMenuInfo(Map<String,String> searchInfo);
	List<Map<String,Object>> getCommCode(Map<String,String> searchInfo);
}
