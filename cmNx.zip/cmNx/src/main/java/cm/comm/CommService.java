package cm.comm;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service("commService")
public class CommService{
	private Logger logger = LoggerFactory.getLogger(CommService.class);
  
    @Resource(name = "commMapper")
    private CommMapper commMapper;
    
    public List<Map<String,Object>> getLoginInfo(Map<String,String> searchInfo) {
    	return commMapper.getLoginInfo(searchInfo);
    }

    public List<Map<String,Object>> getLeftMenuInfo(Map<String,String> searchInfo) {
    	return commMapper.getLeftMenuInfo(searchInfo);
    }
    
    public List<Map<String,Object>> getCommCode(Map<String,String> searchInfo) {
    	return commMapper.getCommCode(searchInfo);
    }    
}
