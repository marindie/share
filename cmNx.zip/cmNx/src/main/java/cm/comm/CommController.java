package cm.comm;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nexacro.uiadapter.spring.core.annotation.ParamDataSet;
import com.nexacro.uiadapter.spring.core.data.NexacroResult;

@Controller
@RequestMapping(value = "/comm")
public class CommController {
  private Logger logger = LoggerFactory.getLogger(CommController.class);
  
    @Resource(name = "commService")
    private CommService commService;
    
    @RequestMapping(value = "/getLoginInfo.nx")
    public NexacroResult getLoginInfo(@ParamDataSet(name = "dsSearch", required = false) Map<String,String> dsSearch) {
      
    	logger.debug("getLoginInfo dsSearch >>> " + dsSearch);

        List<Map<String, Object>> getLoginInfo = commService.getLoginInfo(dsSearch);

        NexacroResult result = new NexacroResult();
        result.addDataSet("output1", getLoginInfo);

        return result;
    }
    
    @RequestMapping(value = "/getLeftMenuInfo.nx")
    public NexacroResult getLeftMenuInfo(@ParamDataSet(name = "dsSearch", required = false) Map<String,String> dsSearch) {
      
    	logger.debug("getLeftMenuInfo dsSearch >>> " + dsSearch);

        List<Map<String, Object>> getLeftMenuInfo = commService.getLeftMenuInfo(dsSearch);
        
        //공통 코드 정보도 같이 세팅
        List<Map<String, Object>> getCommCode = commService.getCommCode(dsSearch);

        NexacroResult result = new NexacroResult();
        result.addDataSet("menuInfo", getLeftMenuInfo);
        result.addDataSet("gdsCode", getCommCode);

        return result;
    }    
}
