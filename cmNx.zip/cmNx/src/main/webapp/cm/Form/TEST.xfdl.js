(function()
{
    return function()
    {
        if (!this._is_form)
            return;
        
        var obj = null;
        
        this.on_create = function()
        {
            this.set_name("TEST");
            this.set_titletext("New Form");
            if (Form == this.constructor)
            {
                this._setFormPosition(1280,720);
            }
            
            // Object(Dataset, ExcelExportObject) Initialize
            obj = new Dataset("dsGrid00", this);
            obj._setContents("<ColumnInfo><Column id=\"USR_ID\" type=\"STRING\" size=\"256\"/><Column id=\"USR_NM\" type=\"STRING\" size=\"256\"/><Column id=\"DEPT_NM\" type=\"STRING\" size=\"256\"/><Column id=\"TEL_NO\" type=\"STRING\" size=\"256\"/><Column id=\"MPHN_NO\" type=\"STRING\" size=\"256\"/><Column id=\"EMAIL\" type=\"STRING\" size=\"256\"/></ColumnInfo>");
            this.addChild(obj.name, obj);


            obj = new Dataset("dsSearch00", this);
            obj._setContents("<ColumnInfo><Column id=\"searchType\" type=\"STRING\" size=\"256\"/><Column id=\"keyword\" type=\"STRING\" size=\"256\"/></ColumnInfo>");
            this.addChild(obj.name, obj);
            
            // UI Components Initialize
            obj = new Button("Button00","350","45","131","50",null,null,null,null,null,null,this);
            obj.set_taborder("0");
            obj.set_text("조회");
            this.addChild(obj.name, obj);

            obj = new Static("Static00","100","30","215","64",null,null,null,null,null,null,this);
            obj.set_taborder("1");
            obj.set_text("Static00");
            this.addChild(obj.name, obj);

            obj = new Grid("Grid00","86","122","678","297",null,null,null,null,null,null,this);
            obj.set_taborder("2");
            obj.set_binddataset("dsGrid00");
            obj.set_autofittype("col");
            obj._setContents("<Formats><Format id=\"default\"><Columns><Column size=\"75\"/><Column size=\"75\"/><Column size=\"75\"/><Column size=\"75\"/><Column size=\"75\"/><Column size=\"75\"/></Columns><Rows><Row size=\"24\" band=\"head\"/><Row size=\"24\"/></Rows><Band id=\"head\"><Cell text=\"아이디\"/><Cell col=\"1\" text=\"이름\"/><Cell col=\"2\" text=\"부서\"/><Cell col=\"3\" text=\"전화번호\"/><Cell col=\"4\" text=\"핸드폰\"/><Cell col=\"5\" text=\"이메일\"/></Band><Band id=\"body\"><Cell text=\"bind:USR_ID\"/><Cell col=\"1\" text=\"bind:USR_NM\"/><Cell col=\"2\" text=\"bind:DEPT_NM\"/><Cell col=\"3\" text=\"bind:TEL_NO\"/><Cell col=\"4\" text=\"bind:MPHN_NO\"/><Cell col=\"5\" text=\"bind:EMAIL\"/></Band></Format></Formats>");
            this.addChild(obj.name, obj);

            obj = new Button("Button01","495","45","131","50",null,null,null,null,null,null,this);
            obj.set_taborder("3");
            obj.set_text("테스트");
            this.addChild(obj.name, obj);
            // Layout Functions
            //-- Default Layout : this
            obj = new Layout("default","",1280,720,this,function(p){});
            obj.set_mobileorientation("landscape");
            this.addLayout(obj.name, obj);
            
            // BindItem Information

            
            // TriggerItem Information

        };
        
        this.loadPreloadList = function()
        {

        };
        
        // User Script
        this.registerScript("TEST.xfdl", function() {

        this.Button00_onclick = function(obj,e)
        {
        	this.fnSearch();
        };

        this.fnSearch = function(){
        	var ds = this.dsSearch00;
        	ds.clearData();
        	var nRow = ds.addRow();
        	ds.setColumn(nRow,"searchType","ID");
        	ds.setColumn(nRow,"keyword","SAMPLE-00001");
        	this.transaction("svcSearch","SvcURL::sample01.nx","dsSearch=dsSearch00","dsGrid00=output1","","fxTrxCallBack",true,"3", false);
        }

        this.fxTrxCallBack = function(svcID, errCD, errMSG){
        	if(svcID == "svcTest"){
        		trace("svcTest Retrieve Success!!!");
        	}else if(svcID == "svcTest"){
        		trace("svcTest Retrieve Success!!!");
        	}
        }



        this.Button01_onclick = function(obj,e)
        {
        	var ds = this.dsSearch00;
        	ds.clearData();
        	var nRow = ds.addRow();
        	ds.setColumn(nRow,"searchType","ID");
        	ds.setColumn(nRow,"keyword","SAMPLE-00001");
        	this.transaction("svcTest","SvcURL::test01.nx","dsSearch=dsSearch00","dsGrid00=output1","","fxTrxCallBack",true,"3", false);
        };

        });
        
        // Regist UI Components Event
        this.on_initEvent = function()
        {
            this.Button00.addEventHandler("onclick",this.Button00_onclick,this);
            this.Button01.addEventHandler("onclick",this.Button01_onclick,this);
        };
        this.loadIncludeScript("TEST.xfdl");
        this.loadPreloadList();
        
        // Remove Reference
        obj = null;
    };
}
)();
