(function()
{
    return function()
    {
        if (!this._is_form)
            return;
        
        var obj = null;
        
        this.on_create = function()
        {
            this.set_name("CMCC0041");
            this.set_titletext("배출처 협의량 관리");
            this.getSetter("scrollbars").set("none");
            if (Form == this.constructor)
            {
                this._setFormPosition(1280,720);
            }
            
            // Object(Dataset, ExcelExportObject) Initialize
            obj = new Dataset("dsTncmcc041", this);
            obj._setContents("<ColumnInfo><Column id=\"manfArCd\" size=\"10\" prop=\"default\" type=\"STRING\"/><Column id=\"manfArCdNm\" size=\"50\" prop=\"default\" type=\"STRING\"/><Column id=\"manfDbetCd\" size=\"10\" prop=\"default\" type=\"STRING\"/><Column id=\"manfDbetCdNm\" size=\"50\" prop=\"default\" type=\"STRING\"/><Column id=\"manfWstCd\" size=\"10\" prop=\"default\" type=\"STRING\"/><Column id=\"manfWstCdNm\" size=\"50\" prop=\"default\" type=\"STRING\"/><Column id=\"wstCd\" size=\"10\" prop=\"default\" type=\"STRING\"/><Column id=\"wstCdNm\" size=\"50\" prop=\"default\" type=\"STRING\"/><Column id=\"wstCd1\" size=\"10\" prop=\"default\" type=\"STRING\"/><Column id=\"wstCdNm1\" size=\"50\" prop=\"default\" type=\"STRING\"/><Column id=\"seqNo\" size=\"10\" prop=\"default\" type=\"INT\"/><Column id=\"arCd\" size=\"10\" prop=\"default\" type=\"STRING\"/><Column id=\"arCdNm\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"dbetCd\" size=\"10\" prop=\"default\" type=\"STRING\"/><Column id=\"dbetCdNm\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"dssId\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"rltBss\" size=\"300\" prop=\"default\" type=\"STRING\"/><Column id=\"rm\" size=\"500\" prop=\"default\" type=\"STRING\"/><Column id=\"cnfAt\" size=\"1\" prop=\"default\" type=\"INT\"/><Column id=\"useAt\" size=\"1\" prop=\"default\" type=\"INT\"/><Column id=\"delAt\" size=\"1\" prop=\"default\" type=\"INT\"/><Column id=\"rgsusr\" size=\"10\" prop=\"default\" type=\"STRING\"/><Column id=\"rgsusrNm\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"rgsDt\" size=\"14\" prop=\"default\" type=\"STRING\"/><Column id=\"updusr\" size=\"10\" prop=\"default\" type=\"STRING\"/><Column id=\"updusrNm\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"updDt\" size=\"14\" prop=\"default\" type=\"STRING\"/><Column id=\"rqtUtCd\" size=\"10\" prop=\"default\" type=\"STRING\"/><Column id=\"extiStDe\" size=\"8\" prop=\"default\" type=\"STRING\"/><Column id=\"extiEdDe\" size=\"8\" prop=\"default\" type=\"STRING\"/><Column id=\"cyfQy\" size=\"20\" prop=\"default\" type=\"BIGDECIMAL\"/><Column id=\"rqtQy\" size=\"20\" prop=\"default\" type=\"BIGDECIMAL\"/><Column id=\"tiQy\" size=\"20\" prop=\"default\" type=\"BIGDECIMAL\"/><Column id=\"dssRqtDe\" size=\"8\" prop=\"default\" type=\"STRING\"/><Column id=\"sdSts\" size=\"2\" prop=\"default\" type=\"STRING\"/><Column id=\"dssPhotoCo\" size=\"3\" prop=\"default\" type=\"INT\"/><Column id=\"manfDbetHp\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"manfDept\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"manfChrUsr\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"wstAtbCd\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"wstAtbCdNm\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"etcWst\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"stedAccqy\" size=\"20\" prop=\"default\" type=\"BIGDECIMAL\"/><Column id=\"rqtQy2\" size=\"20\" prop=\"default\" type=\"BIGDECIMAL\"/><Column id=\"rqtUtCd2\" size=\"10\" prop=\"default\" type=\"STRING\"/><Column id=\"extiStDe2\" size=\"8\" prop=\"default\" type=\"STRING\"/><Column id=\"extiEdDe2\" size=\"8\" prop=\"default\" type=\"STRING\"/><Column id=\"sndngDt\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"preTiQy\" size=\"20\" prop=\"default\" type=\"BIGDECIMAL\"/><Column id=\"psbQy\" size=\"20\" prop=\"default\" type=\"BIGDECIMAL\"/><Column id=\"maxStpDe\" size=\"8\" prop=\"default\" type=\"STRING\"/><Column id=\"maxMerDe\" size=\"8\" prop=\"default\" type=\"STRING\"/><Column id=\"repusr\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"telNo\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"adr\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"fcltyPrcQy\" size=\"20\" prop=\"default\" type=\"BIGDECIMAL\"/><Column id=\"tiPermRate\" size=\"20\" prop=\"default\" type=\"BIGDECIMAL\"/></ColumnInfo>");
            this.addChild(obj.name, obj);


            obj = new Dataset("dsParams", this);
            obj._setContents("<ColumnInfo><Column id=\"dssRqtDeFrom\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"dssRqtDeTo\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"arCd\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"arNm\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"dbetCd\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"dbetNm\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"manfArCd\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"manfArCdNm\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"manfDbetCd\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"manfDbetCdNm\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"manfWstCd\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"manfWstCdNm\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"sdSts\" size=\"256\" prop=\"default\" type=\"STRING\"/></ColumnInfo><Rows><Row><Col id=\"arCd\"/><Col id=\"arNm\"/><Col id=\"dbetCd\"/><Col id=\"dbetNm\"/><Col id=\"dssRqtDeFrom\"/><Col id=\"dssRqtDeTo\"/><Col id=\"manfArCd\"/><Col id=\"manfArCdNm\"/><Col id=\"manfDbetCd\"/><Col id=\"manfDbetCdNm\"/><Col id=\"manfWstCd\"/><Col id=\"manfWstCdNm\"/><Col id=\"sdSts\"/></Row></Rows>");
            this.addChild(obj.name, obj);


            obj = new Dataset("dsExcelList", this);
            obj.set_useclientlayout("1");
            obj._setContents("<ColumnInfo><Column id=\"value\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"dsNm\" size=\"10\" prop=\"default\" type=\"STRING\"/></ColumnInfo><Rows><Row><Col id=\"dsNm\">grdList1</Col><Col id=\"value\">인계서배출처협의량내역</Col></Row></Rows>");
            this.addChild(obj.name, obj);


            obj = new Dataset("dsWstCd", this);
            obj._setContents("<ColumnInfo><Column id=\"wstCd\" size=\"256\" prop=\"default\" type=\"STRING\"/></ColumnInfo>");
            this.addChild(obj.name, obj);


            obj = new Dataset("dsTncmcc041Hst", this);
            obj._setContents("<ColumnInfo><Column id=\"manfArCd\" size=\"10\" prop=\"default\" type=\"STRING\"/><Column id=\"manfArCdNm\" size=\"50\" prop=\"default\" type=\"STRING\"/><Column id=\"manfDbetCd\" size=\"10\" prop=\"default\" type=\"STRING\"/><Column id=\"manfDbetCdNm\" size=\"50\" prop=\"default\" type=\"STRING\"/><Column id=\"manfWstCd\" size=\"10\" prop=\"default\" type=\"STRING\"/><Column id=\"manfWstCdNm\" size=\"50\" prop=\"default\" type=\"STRING\"/><Column id=\"wstCd\" size=\"10\" prop=\"default\" type=\"STRING\"/><Column id=\"wstCdNm\" size=\"50\" prop=\"default\" type=\"STRING\"/><Column id=\"seqNo\" size=\"10\" prop=\"default\" type=\"INT\"/><Column id=\"arCd\" size=\"10\" prop=\"default\" type=\"STRING\"/><Column id=\"arCdNm\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"dbetCd\" size=\"10\" prop=\"default\" type=\"STRING\"/><Column id=\"dbetCdNm\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"dssId\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"rltBss\" size=\"200\" prop=\"default\" type=\"STRING\"/><Column id=\"rm\" size=\"500\" prop=\"default\" type=\"STRING\"/><Column id=\"cnfAt\" size=\"1\" prop=\"default\" type=\"INT\"/><Column id=\"useAt\" size=\"1\" prop=\"default\" type=\"INT\"/><Column id=\"delAt\" size=\"1\" prop=\"default\" type=\"INT\"/><Column id=\"rgsusr\" size=\"10\" prop=\"default\" type=\"STRING\"/><Column id=\"rgsusrNm\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"rgsDt\" size=\"14\" prop=\"default\" type=\"STRING\"/><Column id=\"updusr\" size=\"10\" prop=\"default\" type=\"STRING\"/><Column id=\"updusrNm\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"updDt\" size=\"14\" prop=\"default\" type=\"STRING\"/><Column id=\"rqtUtCd\" size=\"10\" prop=\"default\" type=\"STRING\"/><Column id=\"extiStDe\" size=\"8\" prop=\"default\" type=\"STRING\"/><Column id=\"extiEdDe\" size=\"8\" prop=\"default\" type=\"STRING\"/><Column id=\"cyfQy\" size=\"20\" prop=\"default\" type=\"BIGDECIMAL\"/><Column id=\"rqtQy\" size=\"20\" prop=\"default\" type=\"BIGDECIMAL\"/><Column id=\"tiQy\" size=\"20\" prop=\"default\" type=\"BIGDECIMAL\"/><Column id=\"dssRqtDe\" size=\"8\" prop=\"default\" type=\"STRING\"/><Column id=\"sdSts\" size=\"2\" prop=\"default\" type=\"STRING\"/><Column id=\"dssPhotoCo\" size=\"3\" prop=\"default\" type=\"INT\"/><Column id=\"manfDbetHp\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"wstAtbCd\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"wstAtbCdNm\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"etcWst\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"manfDept\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"manfChrUsr\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"wstCd1\" size=\"10\" prop=\"default\" type=\"STRING\"/><Column id=\"wstCdNm1\" size=\"50\" prop=\"default\" type=\"STRING\"/><Column id=\"sndngDt\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"fcltyPrcQy\" size=\"20\" prop=\"default\" type=\"BIGDECIMAL\"/><Column id=\"tiPermRate\" size=\"20\" prop=\"default\" type=\"BIGDECIMAL\"/></ColumnInfo>");
            this.addChild(obj.name, obj);


            obj = new Dataset("dsDssInfo", this);
            obj._setContents("<ColumnInfo><Column id=\"dssRqtDe\" size=\"8\" prop=\"default\" type=\"STRING\"/><Column id=\"rqtUtCd\" size=\"10\" prop=\"default\" type=\"STRING\"/><Column id=\"extiStDe\" size=\"8\" prop=\"default\" type=\"STRING\"/><Column id=\"extiEdDe\" size=\"8\" prop=\"default\" type=\"STRING\"/><Column id=\"cyfQy\" size=\"20\" prop=\"default\" type=\"BIGDECIMAL\"/><Column id=\"rqtQy\" size=\"20\" prop=\"default\" type=\"BIGDECIMAL\"/><Column id=\"tiQy\" size=\"20\" prop=\"default\" type=\"BIGDECIMAL\"/><Column id=\"dssId\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"wstAtbCd\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"etcWst\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"dbetCd\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"dbetCdNm\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"arCd\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"arCdNm\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"stedAccqy\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"sndngDt\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"wstCd1\" size=\"256\" prop=\"default\" type=\"STRING\"/><Column id=\"wstCdNm1\" size=\"256\" prop=\"default\" type=\"STRING\"/></ColumnInfo>");
            this.addChild(obj.name, obj);


            obj = new Dataset("dsRetData", this);
            obj.set_useclientlayout("1");
            obj._setContents("<ColumnInfo><Column id=\"procCode\" size=\"100\" prop=\"default\" type=\"STRING\"/><Column id=\"procMsg\" size=\"200\" prop=\"default\" type=\"STRING\"/><Column id=\"userId\" size=\"10\" prop=\"default\" type=\"STRING\"/></ColumnInfo>");
            this.addChild(obj.name, obj);
            
            // UI Components Initialize
            obj = new Grid("grdList1","10","200","800","168",null,null,null,null,null,null,this);
            obj.set_binddataset("dsTncmcc041");
            obj.set_cellsizingtype("col");
            obj.set_readonly("false");
            obj.set_enable("true");
            obj.set_scrollpixel("true");
            obj.set_taborder("1");
            obj.set_tabstop("true");
            obj.set_useselcolor("true");
            obj.set_visible("true");
            obj.set_wheelscrollrow("1");
            obj.set_formatid("default");
            obj.set_selecttype("row");
            obj._setContents("<Formats><Format id=\"default\"><Columns><Column band=\"left\" size=\"28\"/><Column size=\"35\"/><Column size=\"56\"/><Column size=\"128\"/><Column size=\"68\"/><Column size=\"146\"/><Column size=\"70\"/><Column size=\"138\"/><Column size=\"56\"/><Column size=\"131\"/><Column size=\"73\"/><Column size=\"110\"/><Column size=\"66\"/><Column size=\"148\"/><Column size=\"104\"/><Column size=\"89\"/><Column size=\"80\"/><Column size=\"93\"/><Column size=\"93\"/><Column size=\"93\"/><Column size=\"56\"/><Column size=\"106\"/><Column size=\"113\"/><Column size=\"113\"/><Column size=\"113\"/><Column size=\"145\"/><Column size=\"121\"/><Column size=\"121\"/><Column size=\"121\"/><Column size=\"100\"/><Column size=\"79\"/><Column size=\"126\"/><Column size=\"127\"/><Column size=\"85\"/><Column size=\"124\"/><Column size=\"87\"/><Column size=\"87\"/><Column size=\"341\"/><Column size=\"87\"/><Column size=\"122\"/><Column size=\"83\"/><Column size=\"117\"/></Columns><Rows><Row size=\"22\" band=\"head\"/><Row size=\"22\" band=\"head\"/><Row size=\"20\"/></Rows><Band id=\"head\"><Cell col=\"1\" displaytype=\"text\" rowspan=\"2\" text=\"순번\"/><Cell col=\"0\" displaytype=\"checkboxcontrol\" edittype=\"checkbox\" rowspan=\"2\"/><Cell col=\"2\" colspan=\"6\" displaytype=\"text\" text=\"올바로인계서배출처정보\"/><Cell col=\"2\" displaytype=\"text\" row=\"1\" text=\"관할지역\"/><Cell col=\"3\" displaytype=\"text\" row=\"1\" text=\"관할지역명\"/><Cell col=\"4\" displaytype=\"text\" row=\"1\" text=\"배출처코드\"/><Cell col=\"5\" displaytype=\"text\" row=\"1\" text=\"배출처명\"/><Cell col=\"6\" displaytype=\"text\" row=\"1\" text=\"폐기물코드\"/><Cell col=\"7\" displaytype=\"text\" row=\"1\" text=\"폐기물명\"/><Cell col=\"8\" colspan=\"34\" displaytype=\"text\" text=\"반입관리시스템\"/><Cell col=\"8\" displaytype=\"text\" row=\"1\" text=\"지역코드\"/><Cell col=\"9\" displaytype=\"text\" row=\"1\" text=\"지역명\"/><Cell col=\"10\" displaytype=\"text\" row=\"1\" text=\"폐기물코드\"/><Cell col=\"11\" displaytype=\"text\" row=\"1\" text=\"폐기물명\"/><Cell col=\"12\" displaytype=\"text\" row=\"1\" text=\"배출처코드\"/><Cell col=\"13\" displaytype=\"text\" row=\"1\" text=\"배출처명\"/><Cell col=\"14\" displaytype=\"text\" row=\"1\" text=\"협의ID\"/><Cell col=\"15\" displaytype=\"text\" row=\"1\" text=\"협의신청일자\"/><Cell col=\"16\" displaytype=\"text\" row=\"1\" text=\"협의신청형식\"/><Cell col=\"17\" displaytype=\"text\" row=\"1\" text=\"협의량(톤)\"/><Cell col=\"18\" displaytype=\"text\" row=\"1\" text=\"전월초과량(톤)\"/><Cell col=\"19\" displaytype=\"text\" row=\"1\" text=\"누적반입량(톤)\"/><Cell col=\"20\" displaytype=\"text\" row=\"1\" text=\"확인여부\"/><Cell col=\"21\" displaytype=\"text\" row=\"1\" text=\"정지/해제\"/><Cell col=\"22\" displaytype=\"text\" row=\"1\" text=\"지자체담당부서\"/><Cell col=\"23\" displaytype=\"text\" row=\"1\" text=\"지자체담당자\"/><Cell col=\"24\" displaytype=\"text\" row=\"1\" text=\"지자체담당자HP\"/><Cell col=\"25\" displaytype=\"text\" row=\"1\" text=\"배출처시설처리용량(톤)\"/><Cell col=\"26\" displaytype=\"text\" row=\"1\" text=\"반입허용비율\"/><Cell col=\"27\" displaytype=\"text\" row=\"1\" text=\"협의신청폐기물종류\"/><Cell col=\"28\" displaytype=\"text\" row=\"1\" text=\"협의폐기물세부성상\"/><Cell col=\"29\" displaytype=\"text\" row=\"1\" text=\"기타폐기물\"/><Cell col=\"30\" displaytype=\"text\" row=\"1\" text=\"협의사진건수\"/><Cell col=\"31\" displaytype=\"text\" row=\"1\" text=\"관련근거\"/><Cell col=\"32\" displaytype=\"text\" row=\"1\" text=\"비고\"/><Cell col=\"33\" displaytype=\"text\" row=\"1\" text=\"최근계량일자\"/><Cell col=\"34\" displaytype=\"text\" row=\"1\" text=\"장기미반입 정지일자\"/><Cell col=\"35\" displaytype=\"text\" row=\"1\" text=\"배출처대표자\"/><Cell col=\"36\" displaytype=\"text\" row=\"1\" text=\"배출처연락처\"/><Cell col=\"37\" displaytype=\"text\" row=\"1\" text=\"배출처 주소\"/><Cell col=\"38\" displaytype=\"text\" row=\"1\" text=\"등록자\"/><Cell col=\"39\" displaytype=\"text\" row=\"1\" text=\"등록일시\"/><Cell col=\"40\" displaytype=\"text\" row=\"1\" text=\"수정자\"/><Cell col=\"41\" displaytype=\"text\" row=\"1\" text=\"수정일시\"/></Band><Band id=\"body\"><Cell col=\"0\" text=\"bind:chkYn\" displaytype=\"checkboxcontrol\" edittype=\"checkbox\" expandsize=\"20\" textAlign=\"left\"/><Cell textAlign=\"center\" col=\"1\" text=\"bind:rowIdx\" displaytype=\"text\" expr=\"currow + 1\"/><Cell textAlign=\"center\" col=\"2\" text=\"bind:manfArCd\" displaytype=\"text\"/><Cell textAlign=\"left\" col=\"3\" text=\"bind:manfArCdNm\" displaytype=\"text\"/><Cell textAlign=\"center\" col=\"4\" text=\"bind:manfDbetCd\" displaytype=\"text\"/><Cell textAlign=\"left\" col=\"5\" text=\"bind:manfDbetCdNm\" displaytype=\"text\"/><Cell textAlign=\"center\" col=\"6\" text=\"bind:manfWstCd\" displaytype=\"text\"/><Cell textAlign=\"left\" col=\"7\" text=\"bind:manfWstCdNm\" displaytype=\"text\"/><Cell textAlign=\"center\" col=\"8\" text=\"bind:arCd\" displaytype=\"text\"/><Cell textAlign=\"left\" col=\"9\" text=\"bind:arCdNm\" displaytype=\"text\"/><Cell textAlign=\"center\" col=\"10\" text=\"bind:wstCd\" displaytype=\"text\"/><Cell textAlign=\"left\" col=\"11\" text=\"bind:wstCdNm\" displaytype=\"text\"/><Cell textAlign=\"center\" col=\"12\" text=\"bind:dbetCd\" displaytype=\"text\"/><Cell textAlign=\"left\" col=\"13\" text=\"bind:dbetCdNm\" displaytype=\"text\"/><Cell textAlign=\"center\" col=\"14\" text=\"bind:dssId\" displaytype=\"text\" maskeditformat=\"@@@-@@@@@@@@-@@\"/><Cell textAlign=\"center\" col=\"15\" text=\"bind:dssRqtDe\" displaytype=\"date\" calendardisplaynulltype=\"none\"/><Cell textAlign=\"center\" col=\"16\" text=\"bind:rqtUtCd\" combocodecol=\"cmnCd\" combodataset=\"gdsCSCode015\" combodatacol=\"cmnCdNm\" displaytype=\"combocontrol\"/><Cell col=\"17\" text=\"bind:rqtQy\" displaytype=\"number\" textAlign=\"left\"/><Cell col=\"18\" text=\"bind:preTiQy\" displaytype=\"number\" textAlign=\"left\"/><Cell col=\"19\" text=\"bind:tiQy\" displaytype=\"number\" textAlign=\"left\"/><Cell textAlign=\"center\" col=\"20\" text=\"bind:cnfAt\" combocodecol=\"cmnCd\" combodataset=\"gdsCSCode033\" combodatacol=\"cmnCdNm\" displaytype=\"combocontrol\"/><Cell textAlign=\"center\" col=\"21\" text=\"bind:sdSts\" combocodecol=\"cmnCd\" combodataset=\"gdsCMCode091\" combodatacol=\"cmnCdNm\" displaytype=\"combocontrol\"/><Cell textAlign=\"center\" col=\"22\" text=\"bind:manfDept\" displaytype=\"text\"/><Cell textAlign=\"center\" col=\"23\" text=\"bind:manfChrUsr\" displaytype=\"text\"/><Cell textAlign=\"center\" col=\"24\" text=\"bind:manfDbetHp\" displaytype=\"text\"/><Cell textAlign=\"right\" col=\"25\" text=\"bind:fcltyPrcQy\" displaytype=\"number\" maskeditformat=\"##0.00\"/><Cell textAlign=\"right\" col=\"26\" text=\"bind:tiPermRate\" displaytype=\"number\" maskeditformat=\"##0.000\"/><Cell col=\"27\" text=\"bind:wstCdNm1\" displaytype=\"text\" textAlign=\"left\"/><Cell col=\"28\" text=\"bind:wstAtbCdNm\" displaytype=\"text\" textAlign=\"left\"/><Cell col=\"29\" text=\"bind:etcWst\" displaytype=\"text\" textAlign=\"left\"/><Cell textAlign=\"center\" col=\"30\" text=\"bind:dssPhotoCo\" displaytype=\"number\"/><Cell col=\"31\" text=\"bind:rltBss\" displaytype=\"text\" textAlign=\"left\"/><Cell col=\"32\" text=\"bind:rm\" displaytype=\"text\" textAlign=\"left\"/><Cell textAlign=\"center\" col=\"33\" text=\"bind:maxMerDe\" displaytype=\"date\" calendardisplaynulltype=\"none\"/><Cell textAlign=\"center\" col=\"34\" text=\"bind:maxStpDe\" displaytype=\"date\" calendardisplaynulltype=\"none\"/><Cell textAlign=\"center\" col=\"35\" text=\"bind:repusr\" displaytype=\"text\"/><Cell textAlign=\"center\" col=\"36\" text=\"bind:telNo\" displaytype=\"text\"/><Cell col=\"37\" text=\"bind:adr\" displaytype=\"text\" textAlign=\"left\"/><Cell textAlign=\"center\" col=\"38\" text=\"bind:rgsusrNm\" displaytype=\"text\"/><Cell textAlign=\"center\" col=\"39\" text=\"bind:rgsDt\" displaytype=\"date\" maskeditformat=\"yyyy-MM-dd HH:mm\" calendardisplaynulltype=\"none\"/><Cell textAlign=\"center\" col=\"40\" text=\"bind:updusrNm\" displaytype=\"text\"/><Cell textAlign=\"center\" col=\"41\" text=\"bind:updDt\" displaytype=\"date\" maskeditformat=\"yyyy-MM-dd HH:mm\" calendardisplaynulltype=\"none\"/></Band></Format></Formats>");
            this.addChild(obj.name, obj);

            obj = new Static("staTitleMiddle","28","169","150","18",null,null,null,null,null,null,this);
            obj.set_taborder("2");
            obj.set_text("인계서배출처협의량내역");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.addChild(obj.name, obj);

            obj = new ImageViewer("imgTitleMiddle","11","172","11","11",null,null,null,null,null,null,this);
            obj.set_taborder("3");
            obj.set_imagealign("left middle");
            this.addChild(obj.name, obj);

            obj = new Static("staTitleTop","32","8","300","18",null,null,null,null,null,null,this);
            obj.set_taborder("4");
            obj.set_text("배출처 협의량 관리[CMCC0041]");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.addChild(obj.name, obj);

            obj = new ImageViewer("imgTitleTop","10","13","12","12",null,null,null,null,null,null,this);
            obj.set_taborder("5");
            obj.set_imagealign("left middle");
            this.addChild(obj.name, obj);

            obj = new Static("staTotalCnt","180","169","80","18",null,null,null,null,null,null,this);
            obj.set_taborder("6");
            obj.set_text("(총 0건)");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.addChild(obj.name, obj);

            obj = new Div("divTop","455","5","355","40",null,null,null,null,null,null,this);
            obj.set_taborder("7");
            obj.getSetter("scrollbars").set("none");
            this.addChild(obj.name, obj);

            obj = new Button("comBtnSave","78","0","58","22",null,null,null,null,null,null,this.divTop.form);
            obj.set_taborder("2");
            obj.set_text("저장");
            this.divTop.addChild(obj.name, obj);

            obj = new Button("comBtnClose","267","0","58","22",null,null,null,null,null,null,this.divTop.form);
            obj.set_taborder("2");
            obj.set_text("닫기");
            this.divTop.addChild(obj.name, obj);

            obj = new Button("comBtnReset","204","0","58","22",null,null,null,null,null,null,this.divTop.form);
            obj.set_taborder("3");
            obj.set_text("초기화");
            this.divTop.addChild(obj.name, obj);

            obj = new Button("comBtnExel","141","0","58","22",null,null,null,null,null,null,this.divTop.form);
            obj.set_taborder("3");
            obj.set_text("엑셀");
            this.divTop.addChild(obj.name, obj);

            obj = new Button("comBtnSearch","15","0","58","22",null,null,null,null,null,null,this.divTop.form);
            obj.set_taborder("1");
            obj.set_text("조회");
            this.divTop.addChild(obj.name, obj);

            obj = new Tab("Tab0","10","378","800","326",null,null,null,null,null,null,this);
            obj.set_taborder("8");
            obj.set_tabstop("false");
            obj.set_showextrabutton("false");
            this.addChild(obj.name, obj);

            obj = new Tabpage("tab1",this.Tab0);
            obj.getSetter("taborder").set("37");
            obj.set_text(" 상세정보 ");
            obj.getSetter("scrollbars").set("none");
            this.Tab0.addChild(obj.name, obj);

            obj = new Static("Static8","5","129","757","26",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_taborder("55");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Static("Static14","5","154","757","26",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_taborder("60");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Static("Static4","5","105","757","26",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_taborder("45");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Static("Static12","5","30","757","26",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_taborder("2");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Static("Static16","5","80","757","26",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_taborder("0");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Static("Static18","5","55","757","26",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_taborder("0");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Static("Static20","5","204","757","46",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_taborder("0");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Static("Static22","5","249","757","46",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_taborder("6");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Static("Static11","5","5","757","26",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_taborder("7");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Static("Static13","5","5","90","26",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_taborder("8");
            obj.set_text("인계서관할지역");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Static("Static34","5","30","90","26",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_taborder("9");
            obj.set_text(" 폐기물");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Static("Static43","260","30","90","26",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_taborder("10");
            obj.set_text(" 지역");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new TextArea("edtRltBss","98","208","660","38",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.getSetter("binddataset").set("dsTncmcc041");
            obj.set_maxlength("300");
            obj.set_taborder("35");
            obj.getSetter("wordwrap").set("char");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Static("Static38","260","53","90","26",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_taborder("13");
            obj.set_text(" 협의신청형식");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Static("Static27","508","30","94","26",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_taborder("1");
            obj.set_text(" 배출처");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Static("Static44","5","249","90","46",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_taborder("2");
            obj.set_text(" 비고");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Static("Static45","5","204","90","46",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_taborder("5");
            obj.set_text(" 관련근거");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Static("Static46","5","55","90","26",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_taborder("3");
            obj.set_text(" 협의량(톤)");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Static("Static47","260","80","90","26",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_taborder("4");
            obj.set_text(" 협의아이디");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Static("Static51","260","5","90","26",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_taborder("6");
            obj.set_text(" 인계서배출처 ");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Static("Static49","508","80","94","26",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_taborder("7");
            obj.set_text(" 협의신청일자");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Edit("edtArCdNm","395","34","94","18",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.getSetter("binddataset").set("dsTncmcc041");
            obj.set_enable("FALSE");
            obj.set_taborder("14");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Button("btnPopArForm","492","36","14","14",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_enable("FALSE");
            obj.set_taborder("15");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Edit("edtWstCd","98","34","40","18",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.getSetter("binddataset").set("dsTncmcc041");
            obj.set_enable("FALSE");
            obj.set_maxlength("6");
            obj.set_taborder("10");
            obj.getSetter("userdata").set("essential");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Edit("edtWstCdNm","140","34","100","18",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.getSetter("binddataset").set("dsTncmcc041");
            obj.set_enable("FALSE");
            obj.set_readonly("true");
            obj.set_taborder("11");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Edit("edtArCd","353","34","40","18",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.getSetter("binddataset").set("dsTncmcc041");
            obj.set_enable("FALSE");
            obj.set_maxlength("3");
            obj.set_taborder("13");
            obj.getSetter("userdata").set("essential");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Static("Static0","508","105","94","26",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_taborder("25");
            obj.set_text(" 정지/해제");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Edit("edtDbetCd","605","34","40","18",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_textAlign("center");
            obj.getSetter("binddataset").set("dsTncmcc041");
            obj.set_enable("FALSE");
            obj.set_taborder("16");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Edit("edtDbetNm","647","34","95","18",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.getSetter("binddataset").set("dsTncmcc041");
            obj.set_enable("FALSE");
            obj.set_taborder("17");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Button("btnPopDbetForm","745","36","14","14",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_defaultbutton("TRUE");
            obj.set_enable("FALSE");
            obj.set_taborder("18");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Combo("cmbRqtUtCd","352","58","138","18",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.getSetter("binddataset").set("dsTncmcc041");
            obj.set_codecolumn("cmnCd");
            obj.set_datacolumn("cmnCdNm");
            obj.set_displayrowcount("5");
            obj.set_enable("FALSE");
            obj.set_innerdataset("gdsCSCode015");
            obj.set_type("filter");
            obj.set_taborder("22");
            obj.getSetter("userdata").set("essential");
            obj.set_index("0");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Static("Static1","260","105","90","26",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_taborder("29");
            obj.set_text("가능반입량(톤)");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Static("Static2","508","55","94","26",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_taborder("30");
            obj.set_text(" 신청총기간");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Static("Static3","508","5","94","26",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_taborder("31");
            obj.set_text(" 인계서폐기물");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Edit("edtManfArCd","98","9","40","18",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.getSetter("binddataset").set("dsTncmcc041");
            obj.set_enable("FALSE");
            obj.set_maxlength("3");
            obj.set_taborder("1");
            obj.getSetter("userdata").set("essential");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Edit("edtManfArCdNm","140","9","100","18",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.getSetter("binddataset").set("dsTncmcc041");
            obj.set_enable("FALSE");
            obj.set_taborder("2");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Button("btnPopManfArForm","244","12","14","14",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_enable("FALSE");
            obj.set_taborder("3");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Edit("edtManfDbetCd","353","9","40","18",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_textAlign("center");
            obj.getSetter("binddataset").set("dsTncmcc041");
            obj.set_enable("FALSE");
            obj.set_taborder("4");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Edit("edtManfDbetCdNm","395","9","94","18",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.getSetter("binddataset").set("dsTncmcc041");
            obj.set_enable("FALSE");
            obj.set_taborder("5");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Button("btnPopManfDbetForm","492","12","14","14",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_enable("FALSE");
            obj.set_taborder("6");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Edit("edtManfWstCd","605","9","40","18",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.getSetter("binddataset").set("dsTncmcc041");
            obj.set_enable("FALSE");
            obj.set_maxlength("6");
            obj.set_taborder("7");
            obj.getSetter("userdata").set("essential");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Edit("edtManfWstCdNm","647","9","95","18",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.getSetter("binddataset").set("dsTncmcc041");
            obj.set_enable("FALSE");
            obj.set_readonly("true");
            obj.set_taborder("8");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Button("btnPopManfWstForm","744","12","14","14",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_enable("FALSE");
            obj.set_taborder("9");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new MaskEdit("makExtiStDe","605","59","74","18",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_textAlign("left");
            obj.getSetter("binddataset").set("dsTncmcc041");
            obj.set_enable("FALSE");
            obj.set_format("####-##-##");
            obj.set_taborder("25");
            obj.set_type("string");
            obj.getSetter("userdata").set("essential");
            obj.set_clipmode("excludespace");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new MaskEdit("makExtiEdDe","684","59","74","18",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_textAlign("left");
            obj.getSetter("binddataset").set("dsTncmcc041");
            obj.set_enable("FALSE");
            obj.set_format("####-##-##");
            obj.set_taborder("26");
            obj.set_type("string");
            obj.getSetter("userdata").set("essential");
            obj.set_clipmode("excludespace");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Button("btnPopWstForm","244","36","14","14",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_enable("FALSE");
            obj.set_taborder("12");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new MaskEdit("edtDssId","353","84","136","18",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.getSetter("binddataset").set("dsTncmcc041");
            obj.set_enable("FALSE");
            obj.set_format("@@@-@@@@@@@@-@@");
            obj.set_taborder("19");
            obj.set_type("string");
            obj.set_clipmode("excludespace");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Button("btnPopDssIdForm","492","85","14","14",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_enable("FALSE");
            obj.set_taborder("20");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Static("Static5","5","80","90","26",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_taborder("46");
            obj.set_text("전월초과량(톤)");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new MaskEdit("makDssRqtDe","605","84","136","18",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_textAlign("left");
            obj.getSetter("binddataset").set("dsTncmcc041");
            obj.set_enable("FALSE");
            obj.set_format("####-##-##");
            obj.set_taborder("21");
            obj.set_type("string");
            obj.getSetter("userdata").set("essential");
            obj.set_clipmode("excludespace");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Static("Static6","5","105","90","26",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_taborder("48");
            obj.set_text("누적반입량(톤)");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new MaskEdit("makDssQy","97","59","142","18",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_textAlign("right");
            obj.getSetter("binddataset").set("dsTncmcc041");
            obj.set_enable("FALSE");
            obj.set_taborder("23");
            obj.getSetter("userdata").set("essential");
            obj.set_clipmode("excludespace");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new MaskEdit("makStedAccqy","97","84","142","18",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_textAlign("right");
            obj.getSetter("binddataset").set("dsTncmcc041");
            obj.set_enable("FALSE");
            obj.set_taborder("27");
            obj.getSetter("userdata").set("essential");
            obj.set_clipmode("excludespace");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new MaskEdit("makTiQy","97","109","142","18",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_textAlign("right");
            obj.getSetter("binddataset").set("dsTncmcc041");
            obj.set_enable("FALSE");
            obj.set_taborder("24");
            obj.getSetter("userdata").set("essential");
            obj.set_clipmode("excludespace");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Combo("cmbSdSts","604","108","138","18",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.getSetter("binddataset").set("dsTncmcc041");
            obj.set_codecolumn("cmnCd");
            obj.set_datacolumn("cmnCdNm");
            obj.set_enable("FALSE");
            obj.set_imemode("none");
            obj.set_innerdataset("gdsCMCode091");
            obj.set_taborder("28");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new MaskEdit("makDssPhotoCo","605","133","136","18",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_textAlign("right");
            obj.getSetter("binddataset").set("dsTncmcc041");
            obj.set_enable("FALSE");
            obj.set_taborder("31");
            obj.getSetter("userdata").set("essential");
            obj.set_clipmode("excludespace");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Static("Static9","5","129","90","26",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_taborder("56");
            obj.set_text(" 협의폐기물  세부성상");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Edit("edtManfDbetHp","605","158","136","18",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.getSetter("binddataset").set("dsTncmcc041");
            obj.set_imemode("none");
            obj.set_maxlength("30");
            obj.set_taborder("34");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Combo("cmbWstAtbCd","240","132","124","18",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.getSetter("binddataset").set("dsTncmcc041");
            obj.set_codecolumn("CmnCd");
            obj.set_datacolumn("CmnCdNm");
            obj.set_displayrowcount("5");
            obj.set_enable("FALSE");
            obj.set_innerdataset("gdsCSCode031");
            obj.set_type("filter");
            obj.set_taborder("29");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Edit("edtEtcWst","365","133","140","18",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.getSetter("binddataset").set("dsTncmcc041");
            obj.set_enable("FALSE");
            obj.set_imemode("none");
            obj.set_taborder("30");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Static("Static15","5","154","90","26",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_taborder("61");
            obj.set_text("지자체담당부서");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Static("Static17","260","154","90","26",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_taborder("62");
            obj.set_text(" 지자체 담당자");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Static("Static19","508","154","94","26",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_taborder("63");
            obj.set_text(" 지자체담당자HP");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Static("Static10","508","129","94","26",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_taborder("64");
            obj.set_text(" 협의사진건수");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Edit("edtManfDept","98","158","142","18",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.getSetter("binddataset").set("dsTncmcc041");
            obj.set_imemode("none");
            obj.set_maxlength("30");
            obj.set_taborder("32");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Edit("edtManfChrUsr","353","158","136","18",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.getSetter("binddataset").set("dsTncmcc041");
            obj.set_imemode("none");
            obj.set_maxlength("30");
            obj.set_taborder("33");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Edit("Edit0","98","133","140","18",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.getSetter("binddataset").set("dsTncmcc041");
            obj.set_enable("FALSE");
            obj.set_imemode("none");
            obj.set_taborder("67");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new TextArea("edtRm","98","253","660","38",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.getSetter("binddataset").set("dsTncmcc041");
            obj.set_maxlength("200");
            obj.set_taborder("68");
            obj.getSetter("wordwrap").set("char");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new MaskEdit("MaskEdit0","353","109","136","18",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_textAlign("right");
            obj.getSetter("binddataset").set("dsTncmcc041");
            obj.set_enable("FALSE");
            obj.set_taborder("69");
            obj.getSetter("userdata").set("essential");
            obj.set_clipmode("excludespace");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Static("Static7","5","179","757","26",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_taborder("71");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Static("Static21","5","179","90","26",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_taborder("72");
            obj.set_text("시설처리용량톤");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Static("Static23","260","179","90","26",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_taborder("72");
            obj.set_text(" 반입허용비율");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Static("Static24","508","179","94","26",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_taborder("70");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new MaskEdit("makTiPermRate","353","183","136","18",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_textAlign("right");
            obj.getSetter("binddataset").set("dsTncmcc041");
            obj.set_enable("FALSE");
            obj.set_format("##0.000");
            obj.set_taborder("74");
            obj.getSetter("userdata").set("essential");
            obj.set_clipmode("excludespace");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new MaskEdit("makFcltyPrcQy","98","183","142","18",null,null,null,null,null,null,this.Tab0.tab1.form);
            obj.set_textAlign("right");
            obj.getSetter("binddataset").set("dsTncmcc041");
            obj.set_format("##0.00");
            obj.set_taborder("75");
            obj.getSetter("userdata").set("essential");
            obj.set_clipmode("excludespace");
            this.Tab0.tab1.addChild(obj.name, obj);

            obj = new Tabpage("tab3",this.Tab0);
            obj.getSetter("taborder").set("3");
            obj.set_text(" 이력정보 ");
            obj.getSetter("scrollbars").set("none");
            this.Tab0.addChild(obj.name, obj);

            obj = new Grid("grdListHst","4","3","757","292",null,null,null,null,null,null,this.Tab0.tab3.form);
            obj.set_binddataset("dsTncmcc041Hst");
            obj.set_cellsizingtype("col");
            obj.set_readonly("false");
            obj.set_enable("true");
            obj.set_scrollpixel("true");
            obj.set_taborder("1");
            obj.set_tabstop("true");
            obj.set_useselcolor("true");
            obj.set_visible("true");
            obj.set_wheelscrollrow("1");
            obj.set_formatid("default");
            obj.set_selecttype("row");
            obj._setContents("<Formats><Format id=\"default\"><Columns><Column band=\"left\" size=\"35\"/><Column size=\"56\"/><Column size=\"128\"/><Column size=\"68\"/><Column size=\"146\"/><Column size=\"70\"/><Column size=\"138\"/><Column size=\"56\"/><Column size=\"131\"/><Column size=\"73\"/><Column size=\"110\"/><Column size=\"66\"/><Column size=\"148\"/><Column size=\"105\"/><Column size=\"89\"/><Column size=\"74\"/><Column size=\"80\"/><Column size=\"80\"/><Column size=\"56\"/><Column size=\"110\"/><Column size=\"113\"/><Column size=\"113\"/><Column size=\"113\"/><Column size=\"114\"/><Column size=\"120\"/><Column size=\"120\"/><Column size=\"121\"/><Column size=\"126\"/><Column size=\"126\"/><Column size=\"159\"/><Column size=\"87\"/><Column size=\"122\"/><Column size=\"83\"/><Column size=\"117\"/></Columns><Rows><Row size=\"22\" band=\"head\"/><Row size=\"22\" band=\"head\"/><Row size=\"20\"/></Rows><Band id=\"head\"><Cell col=\"0\" displaytype=\"text\" rowspan=\"2\" text=\"순번\"/><Cell col=\"1\" colspan=\"6\" displaytype=\"text\" text=\"올바로인계서배출처정보\"/><Cell col=\"7\" colspan=\"27\" displaytype=\"text\" text=\"반입관리시스템\"/><Cell col=\"1\" displaytype=\"text\" row=\"1\" text=\"관할지역\"/><Cell col=\"2\" displaytype=\"text\" row=\"1\" text=\"관할지역명\"/><Cell col=\"3\" displaytype=\"text\" row=\"1\" text=\"배출처코드\"/><Cell col=\"4\" displaytype=\"text\" row=\"1\" text=\"배출처명\"/><Cell col=\"5\" displaytype=\"text\" row=\"1\" text=\"폐기물코드\"/><Cell col=\"6\" displaytype=\"text\" row=\"1\" text=\"폐기물명\"/><Cell col=\"7\" displaytype=\"text\" row=\"1\" text=\"지역코드\"/><Cell col=\"8\" displaytype=\"text\" row=\"1\" text=\"지역명\"/><Cell col=\"9\" displaytype=\"text\" row=\"1\" text=\"폐기물코드\"/><Cell col=\"10\" displaytype=\"text\" row=\"1\" text=\"폐기물명\"/><Cell col=\"11\" displaytype=\"text\" row=\"1\" text=\"배출처코드\"/><Cell col=\"12\" displaytype=\"text\" row=\"1\" text=\"배출처명\"/><Cell col=\"13\" displaytype=\"text\" row=\"1\" text=\"협의ID\"/><Cell col=\"14\" displaytype=\"text\" row=\"1\" text=\"협의신청일자\"/><Cell col=\"15\" displaytype=\"text\" row=\"1\" text=\"협의량\"/><Cell col=\"16\" displaytype=\"text\" row=\"1\" text=\"협의신청형식\"/><Cell col=\"17\" displaytype=\"text\" row=\"1\" text=\"누적반입량\"/><Cell col=\"18\" displaytype=\"text\" row=\"1\" text=\"확인여부\"/><Cell col=\"19\" displaytype=\"text\" row=\"1\" text=\"정지/해제\"/><Cell col=\"20\" displaytype=\"text\" row=\"1\" text=\"올바로협의담당부서\"/><Cell col=\"21\" displaytype=\"text\" row=\"1\" text=\"올바로협의담당자\"/><Cell col=\"22\" displaytype=\"text\" row=\"1\" text=\"올바로협의담당자HP\"/><Cell col=\"23\" displaytype=\"text\" row=\"1\" text=\"시설처리용량(톤)\"/><Cell col=\"24\" displaytype=\"text\" row=\"1\" text=\"반입허용비율\"/><Cell col=\"25\" displaytype=\"text\" row=\"1\" text=\"협의신청폐기물종류\"/><Cell col=\"26\" displaytype=\"text\" row=\"1\" text=\"협의폐기물세부성상\"/><Cell col=\"27\" displaytype=\"text\" row=\"1\" text=\"기타폐기물\"/><Cell col=\"28\" displaytype=\"text\" row=\"1\" text=\"관련근거\"/><Cell col=\"29\" displaytype=\"text\" row=\"1\" text=\"비고\"/><Cell col=\"30\" displaytype=\"text\" row=\"1\" text=\"등록자\"/><Cell col=\"31\" displaytype=\"text\" row=\"1\" text=\"등록일시\"/><Cell col=\"32\" displaytype=\"text\" row=\"1\" text=\"수정자\"/><Cell col=\"33\" displaytype=\"text\" row=\"1\" text=\"수정일시\"/></Band><Band id=\"body\"><Cell textAlign=\"center\" col=\"0\" text=\"bind:rowIdx\" displaytype=\"text\" expr=\"currow + 1\"/><Cell textAlign=\"center\" col=\"1\" text=\"bind:manfArCd\" displaytype=\"text\"/><Cell textAlign=\"left\" col=\"2\" text=\"bind:manfArCdNm\" displaytype=\"text\"/><Cell textAlign=\"center\" col=\"3\" text=\"bind:manfDbetCd\" displaytype=\"text\"/><Cell textAlign=\"left\" col=\"4\" text=\"bind:manfDbetCdNm\" displaytype=\"text\"/><Cell textAlign=\"center\" col=\"5\" text=\"bind:manfWstCd\" displaytype=\"text\"/><Cell textAlign=\"left\" col=\"6\" text=\"bind:manfWstCdNm\" displaytype=\"text\"/><Cell textAlign=\"center\" col=\"7\" text=\"bind:arCd\" displaytype=\"text\"/><Cell textAlign=\"left\" col=\"8\" text=\"bind:arCdNm\" displaytype=\"text\"/><Cell textAlign=\"center\" col=\"9\" text=\"bind:wstCd\" displaytype=\"text\"/><Cell textAlign=\"left\" col=\"10\" text=\"bind:wstCdNm\" displaytype=\"text\"/><Cell textAlign=\"center\" col=\"11\" text=\"bind:dbetCd\" displaytype=\"text\"/><Cell textAlign=\"left\" col=\"12\" text=\"bind:dbetCdNm\" displaytype=\"text\"/><Cell textAlign=\"center\" col=\"13\" text=\"bind:dssId\" displaytype=\"text\" maskeditformat=\"###-######-##-##\"/><Cell textAlign=\"center\" col=\"14\" text=\"bind:dssRqtDe\" displaytype=\"date\" calendardisplaynulltype=\"none\"/><Cell col=\"15\" text=\"bind:rqtQy\" displaytype=\"number\" textAlign=\"left\"/><Cell textAlign=\"center\" col=\"16\" text=\"bind:rqtUtCd\" combocodecol=\"cmnCd\" combodataset=\"gdsCSCode015\" combodatacol=\"cmnCdNm\" displaytype=\"combocontrol\"/><Cell col=\"17\" text=\"bind:tiQy\" displaytype=\"number\" textAlign=\"left\"/><Cell textAlign=\"center\" col=\"18\" text=\"bind:cnfAt\" combocodecol=\"cmnCd\" combodataset=\"gdsCSCode033\" combodatacol=\"cmnCdNm\" displaytype=\"combocontrol\"/><Cell textAlign=\"center\" col=\"19\" text=\"bind:sdSts\" combocodecol=\"cmnCd\" combodataset=\"gdsCMCode091\" combodatacol=\"cmnCdNm\" displaytype=\"combocontrol\"/><Cell textAlign=\"center\" col=\"20\" text=\"bind:manfDept\" displaytype=\"text\"/><Cell textAlign=\"center\" col=\"21\" text=\"bind:manfChrUsr\" displaytype=\"text\"/><Cell textAlign=\"center\" col=\"22\" text=\"bind:manfDbetHp\" displaytype=\"text\"/><Cell textAlign=\"right\" col=\"23\" text=\"bind:fcltyPrcQy\" displaytype=\"number\" maskeditformat=\"##0.00\"/><Cell textAlign=\"right\" col=\"24\" text=\"bind:tiPermRate\" displaytype=\"number\" maskeditformat=\"##0.00\"/><Cell col=\"25\" text=\"bind:wstCdNm1\" displaytype=\"text\" textAlign=\"left\"/><Cell col=\"26\" text=\"bind:wstAtbCdNm\" displaytype=\"text\" textAlign=\"left\"/><Cell col=\"27\" text=\"bind:etcWst\" displaytype=\"text\" textAlign=\"left\"/><Cell col=\"28\" text=\"bind:rltBss\" displaytype=\"text\" textAlign=\"left\"/><Cell col=\"29\" text=\"bind:rm\" displaytype=\"text\" textAlign=\"left\"/><Cell textAlign=\"center\" col=\"30\" text=\"bind:rgsusrNm\" displaytype=\"text\"/><Cell textAlign=\"center\" col=\"31\" text=\"bind:rgsDt\" displaytype=\"date\" maskeditformat=\"yyyy-MM-dd HH:mm\" calendardisplaynulltype=\"none\"/><Cell textAlign=\"center\" col=\"32\" text=\"bind:updusrNm\" displaytype=\"text\"/><Cell textAlign=\"center\" col=\"33\" text=\"bind:updDt\" displaytype=\"date\" maskeditformat=\"yyyy-MM-dd HH:mm\" calendardisplaynulltype=\"none\"/></Band></Format></Formats>");
            this.Tab0.tab3.addChild(obj.name, obj);

            obj = new Div("divMiddle","520","165","290","25",null,null,null,null,null,null,this);
            obj.set_taborder("9");
            obj.set_text("Div1");
            obj.getSetter("scrollbars").set("none");
            this.addChild(obj.name, obj);

            obj = new Button("btnDelete","197","0","61","20",null,null,null,null,null,null,this.divMiddle.form);
            obj.set_taborder("2");
            this.divMiddle.addChild(obj.name, obj);

            obj = new Button("btnAppend","133","0","61","20",null,null,null,null,null,null,this.divMiddle.form);
            obj.set_taborder("1");
            this.divMiddle.addChild(obj.name, obj);

            obj = new Button("btnTrn","69","0","61","20",null,null,null,null,null,null,this.divMiddle.form);
            obj.set_taborder("3");
            obj.set_text("전송");
            this.divMiddle.addChild(obj.name, obj);

            obj = new Div("divHead","10","40","800","75",null,null,null,null,null,null,this);
            obj.set_taborder("10");
            obj.getSetter("scrollbars").set("none");
            this.addChild(obj.name, obj);

            obj = new Static("Static1","278","23","80","18",null,null,null,null,null,null,this.divHead.form);
            obj.set_textAlign("right");
            obj.set_taborder("20");
            obj.set_text("인계서배출처");
            obj.set_verticalAlign("middle");
            this.divHead.addChild(obj.name, obj);

            obj = new Edit("edtSrchManfArCdNm","152","23","94","18",null,null,null,null,null,null,this.divHead.form);
            obj.getSetter("binddataset").set("dsParams");
            obj.set_readonly("true");
            obj.set_taborder("12");
            this.divHead.addChild(obj.name, obj);

            obj = new Edit("edtSrchManfArCd","102","23","48","18",null,null,null,null,null,null,this.divHead.form);
            obj.getSetter("binddataset").set("dsParams");
            obj.set_imemode("none");
            obj.set_maxlength("3");
            obj.set_inputtype("number");
            obj.set_taborder("10");
            this.divHead.addChild(obj.name, obj);

            obj = new Static("Static2","72","47","26","18",null,null,null,null,null,null,this.divHead.form);
            obj.set_textAlign("right");
            obj.set_taborder("2");
            obj.set_text("지역");
            obj.set_verticalAlign("middle");
            this.divHead.addChild(obj.name, obj);

            obj = new Edit("edtSrchArCd","102","47","48","18",null,null,null,null,null,null,this.divHead.form);
            obj.set_textAlign("center");
            obj.getSetter("binddataset").set("dsParams");
            obj.set_imemode("none");
            obj.set_maxlength("3");
            obj.set_inputtype("number");
            obj.set_taborder("3");
            this.divHead.addChild(obj.name, obj);

            obj = new Edit("edtSrchArNm","152","47","94","18",null,null,null,null,null,null,this.divHead.form);
            obj.getSetter("binddataset").set("dsParams");
            obj.set_readonly("true");
            obj.set_taborder("4");
            this.divHead.addChild(obj.name, obj);

            obj = new Button("btnPopSrchAr","249","49","31","20",null,null,null,null,null,null,this.divHead.form);
            obj.set_taborder("5");
            obj.set_icon("url(\'Images::img_b_search.png\')");
            obj.set_iconPosition("top");
            this.divHead.addChild(obj.name, obj);

            obj = new Static("Static3","304","47","52","18",null,null,null,null,null,null,this.divHead.form);
            obj.set_textAlign("right");
            obj.set_taborder("6");
            obj.set_text("배출업소");
            obj.set_verticalAlign("middle");
            this.divHead.addChild(obj.name, obj);

            obj = new Edit("edtSrchDbetCd","360","47","48","18",null,null,null,null,null,null,this.divHead.form);
            obj.set_textAlign("center");
            obj.getSetter("binddataset").set("dsParams");
            obj.set_maxlength("10");
            obj.set_inputtype("number");
            obj.set_taborder("7");
            this.divHead.addChild(obj.name, obj);

            obj = new Edit("edtSrchDbetNm","410","47","94","18",null,null,null,null,null,null,this.divHead.form);
            obj.getSetter("binddataset").set("dsParams");
            obj.set_readonly("true");
            obj.set_taborder("8");
            this.divHead.addChild(obj.name, obj);

            obj = new Button("btnPopSrchDbet","507","49","31","20",null,null,null,null,null,null,this.divHead.form);
            obj.set_taborder("9");
            obj.set_icon("url(\'Images::img_b_search.png\')");
            obj.set_iconPosition("top");
            this.divHead.addChild(obj.name, obj);

            obj = new ImageViewer("bgSearchLeft","0","0","5","59",null,null,null,null,null,null,this.divHead.form);
            obj.set_taborder("0");
            obj.set_imagealign("left middle");
            this.divHead.addChild(obj.name, obj);

            obj = new ImageViewer("bgSearchRight","765","0","5","59",null,null,null,null,null,null,this.divHead.form);
            obj.set_taborder("1");
            obj.set_imagealign("left middle");
            this.divHead.addChild(obj.name, obj);

            obj = new Button("btnPopSrchManfAr","248","19","31","20",null,null,null,null,null,null,this.divHead.form);
            obj.set_taborder("11");
            obj.set_icon("url(\'Images::img_b_search.png\')");
            obj.set_iconPosition("left");
            this.divHead.addChild(obj.name, obj);

            obj = new Edit("edtSrchManfDbetCd","360","23","48","18",null,null,null,null,null,null,this.divHead.form);
            obj.set_textAlign("center");
            obj.getSetter("binddataset").set("dsParams");
            obj.set_inputtype("number");
            obj.set_taborder("13");
            this.divHead.addChild(obj.name, obj);

            obj = new Edit("edtSrchManfDbetCdNm","410","23","94","18",null,null,null,null,null,null,this.divHead.form);
            obj.getSetter("binddataset").set("dsParams");
            obj.set_readonly("true");
            obj.set_taborder("14");
            this.divHead.addChild(obj.name, obj);

            obj = new Button("btnPopSrchManfDbet","507","25","31","20",null,null,null,null,null,null,this.divHead.form);
            obj.set_taborder("15");
            obj.set_icon("url(\'Images::img_b_search.png\')");
            obj.set_iconPosition("top");
            this.divHead.addChild(obj.name, obj);

            obj = new Edit("edtSrchManfWstCd","613","23","40","18",null,null,null,null,null,null,this.divHead.form);
            obj.getSetter("binddataset").set("dsParams");
            obj.set_maxlength("6");
            obj.set_taborder("16");
            this.divHead.addChild(obj.name, obj);

            obj = new Edit("edtSrchManfWstCdNm","655","23","95","18",null,null,null,null,null,null,this.divHead.form);
            obj.getSetter("binddataset").set("dsParams");
            obj.set_readonly("true");
            obj.set_taborder("17");
            this.divHead.addChild(obj.name, obj);

            obj = new Button("btnPopSrchManfWst","752","25","31","20",null,null,null,null,null,null,this.divHead.form);
            obj.set_taborder("18");
            obj.set_icon("url(\'Images::img_b_search.png\')");
            obj.set_iconPosition("top");
            this.divHead.addChild(obj.name, obj);

            obj = new Static("Static0","-2","23","100","18",null,null,null,null,null,null,this.divHead.form);
            obj.set_textAlign("right");
            obj.set_taborder("19");
            obj.set_text("인계서관할지역");
            obj.set_verticalAlign("middle");
            this.divHead.addChild(obj.name, obj);

            obj = new Static("Static4","530","23","80","18",null,null,null,null,null,null,this.divHead.form);
            obj.set_textAlign("right");
            obj.set_taborder("21");
            obj.set_text("인계서폐기물");
            obj.set_verticalAlign("middle");
            this.divHead.addChild(obj.name, obj);

            obj = new Combo("cmbSrchSdSts","535","47","130","18",null,null,null,null,null,null,this.divHead.form);
            obj.getSetter("binddataset").set("dsParams");
            obj.set_imemode("none");
            obj.set_type("filter");
            obj.set_taborder("22");
            this.divHead.addChild(obj.name, obj);

            obj = new Static("Static1","0","118","552","25",null,null,null,null,null,null,this);
            obj.set_taborder("11");
            obj.set_text(" ※ 협의량 추가는 아래 협의량(톤) 입력란을 이용하여 추가 반입량 등록");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.addChild(obj.name, obj);

            obj = new Static("Static0","0","132","552","25",null,null,null,null,null,null,this);
            obj.set_taborder("12");
            obj.set_text(" ※ 전송버튼 선택시 인계서 시료검사 배출업소 정보와  연계 처리 됩니다.");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.addChild(obj.name, obj);

            obj = new Static("Static2","0","146","552","25",null,null,null,null,null,null,this);
            obj.set_taborder("13");
            obj.set_text(" ※ 반입허용비율은 시설처리용량 대비 반입허용량이며 단위기준은 신청형식 기준입니다.");
            obj.set_verticalAlign("middle");
            obj.set_textAlign("left");
            this.addChild(obj.name, obj);
            // Layout Functions
            //-- Default Layout : this
            obj = new Layout("default","",this._adjust_width,this._adjust_height,this,function(p){});
            this.addLayout(obj.name, obj);
            
            // BindItem Information
            obj = new BindItem("Tab0_tab1_form_edtRltBss_value","Tab0.tab1.form.edtRltBss","value","dsTncmcc041","rltBss");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("Tab0_tab1_form_edtArCdNm_value","Tab0.tab1.form.edtArCdNm","value","dsTncmcc041","arCdNm");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("Tab0_tab1_form_edtWstCd_value","Tab0.tab1.form.edtWstCd","value","dsTncmcc041","wstCd");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("Tab0_tab1_form_edtWstCdNm_value","Tab0.tab1.form.edtWstCdNm","value","dsTncmcc041","wstCdNm");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("Tab0_tab1_form_edtArCd_value","Tab0.tab1.form.edtArCd","value","dsTncmcc041","arCd");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("Tab0_tab1_form_edtDbetCd_value","Tab0.tab1.form.edtDbetCd","value","dsTncmcc041","dbetCd");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("Tab0_tab1_form_edtDbetNm_value","Tab0.tab1.form.edtDbetNm","value","dsTncmcc041","dbetCdNm");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("Tab0_tab1_form_cmbRqtUtCd_value","Tab0.tab1.form.cmbRqtUtCd","value","dsTncmcc041","rqtUtCd");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("Tab0_tab1_form_edtManfArCd_value","Tab0.tab1.form.edtManfArCd","value","dsTncmcc041","manfArCd");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("Tab0_tab1_form_edtManfArCdNm_value","Tab0.tab1.form.edtManfArCdNm","value","dsTncmcc041","manfArCdNm");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("Tab0_tab1_form_edtManfDbetCd_value","Tab0.tab1.form.edtManfDbetCd","value","dsTncmcc041","manfDbetCd");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("Tab0_tab1_form_edtManfDbetCdNm_value","Tab0.tab1.form.edtManfDbetCdNm","value","dsTncmcc041","manfDbetCdNm");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("Tab0_tab1_form_edtManfWstCd_value","Tab0.tab1.form.edtManfWstCd","value","dsTncmcc041","manfWstCd");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("Tab0_tab1_form_edtManfWstCdNm_value","Tab0.tab1.form.edtManfWstCdNm","value","dsTncmcc041","manfWstCdNm");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("Tab0_tab1_form_makExtiStDe_value","Tab0.tab1.form.makExtiStDe","value","dsTncmcc041","extiStDe");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("Tab0_tab1_form_makExtiEdDe_value","Tab0.tab1.form.makExtiEdDe","value","dsTncmcc041","extiEdDe");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("Tab0_tab1_form_edtDssId_value","Tab0.tab1.form.edtDssId","value","dsTncmcc041","dssId");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("Tab0_tab1_form_makDssRqtDe_value","Tab0.tab1.form.makDssRqtDe","value","dsTncmcc041","dssRqtDe");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("Tab0_tab1_form_makDssQy_value","Tab0.tab1.form.makDssQy","value","dsTncmcc041","rqtQy");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("Tab0_tab1_form_makStedAccqy_value","Tab0.tab1.form.makStedAccqy","value","dsTncmcc041","preTiQy");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("Tab0_tab1_form_makTiQy_value","Tab0.tab1.form.makTiQy","value","dsTncmcc041","tiQy");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("Tab0_tab1_form_cmbSdSts_value","Tab0.tab1.form.cmbSdSts","value","dsTncmcc041","sdSts");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("Tab0_tab1_form_makDssPhotoCo_value","Tab0.tab1.form.makDssPhotoCo","value","dsTncmcc041","dssPhotoCo");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("Tab0_tab1_form_edtManfDbetHp_value","Tab0.tab1.form.edtManfDbetHp","value","dsTncmcc041","manfDbetHp");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("Tab0_tab1_form_cmbWstAtbCd_value","Tab0.tab1.form.cmbWstAtbCd","value","dsTncmcc041","wstAtbCd");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("Tab0_tab1_form_edtEtcWst_value","Tab0.tab1.form.edtEtcWst","value","dsTncmcc041","etcWst");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("Tab0_tab1_form_edtManfDept_value","Tab0.tab1.form.edtManfDept","value","dsTncmcc041","manfDept");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("Tab0_tab1_form_edtManfChrUsr_value","Tab0.tab1.form.edtManfChrUsr","value","dsTncmcc041","manfChrUsr");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("Tab0_tab1_form_Edit0_value","Tab0.tab1.form.Edit0","value","dsTncmcc041","wstCdNm1");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("Tab0_tab1_form_edtRm_value","Tab0.tab1.form.edtRm","value","dsTncmcc041","rm");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("Tab0_tab1_form_MaskEdit0_value","Tab0.tab1.form.MaskEdit0","value","dsTncmcc041","psbQy");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("Tab0_tab1_form_makTiPermRate_value","Tab0.tab1.form.makTiPermRate","value","dsTncmcc041","tiPermRate");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("Tab0_tab1_form_makFcltyPrcQy_value","Tab0.tab1.form.makFcltyPrcQy","value","dsTncmcc041","fcltyPrcQy");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("divHead_form_edtSrchManfArCdNm_value","divHead.form.edtSrchManfArCdNm","value","dsParams","manfArCdNm");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("divHead_form_edtSrchManfArCd_value","divHead.form.edtSrchManfArCd","value","dsParams","manfArCd");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("divHead_form_edtSrchArCd_value","divHead.form.edtSrchArCd","value","dsParams","arCd");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("divHead_form_edtSrchArNm_value","divHead.form.edtSrchArNm","value","dsParams","arNm");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("divHead_form_edtSrchDbetCd_value","divHead.form.edtSrchDbetCd","value","dsParams","dbetCd");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("divHead_form_edtSrchDbetNm_value","divHead.form.edtSrchDbetNm","value","dsParams","dbetNm");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("divHead_form_edtSrchManfDbetCd_value","divHead.form.edtSrchManfDbetCd","value","dsParams","manfDbetCd");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("divHead_form_edtSrchManfDbetCdNm_value","divHead.form.edtSrchManfDbetCdNm","value","dsParams","manfDbetCdNm");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("divHead_form_edtSrchManfWstCd_value","divHead.form.edtSrchManfWstCd","value","dsParams","manfWstCd");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("divHead_form_edtSrchManfWstCdNm_value","divHead.form.edtSrchManfWstCdNm","value","dsParams","manfWstCdNm");
            this.addChild(obj.name, obj);
            obj.bind();

            obj = new BindItem("divHead_form_cmbSrchSdSts_value","divHead.form.cmbSrchSdSts","value","dsParams","sdSts");
            this.addChild(obj.name, obj);
            obj.bind();
            
            // TriggerItem Information

        };
        
        this.loadPreloadList = function()
        {

        };
        
        // User Script
        this.addIncludeScript("CMCC000103.xfdl","Lib::COMM_DS.xjs");
        this.registerScript("CMCC000103.xfdl", function() {
        this.executeIncludeScript("Lib::COMM_DS.xjs"); /*include "Lib::COMM_DS.xjs"*/;

        this.fn_ButtonOnClickHandler = function(obj,e)
        {
        	trace(obj.id);
        	switch(obj.id)
        	{
        		case "comBtnSearch" 	: this.fn_Select(obj);			break;						// 조회 버튼
        	}
        };

        this.fn_Select = function(obj){
        	trace(this.divHead.form.edtSrchManfArCd.value);
        	this.transaction("getCoAmt","SvcURL::/CMCC00103/getCoAmt.nx","dsSearch=dsParam","dsTncmcc041=dsRet dsTncmcc041Hst=dsRet","","fx_TrxCallBack", true, 3, false);
        }

        this.fx_TrxCallBack = function(svcID, errCD, errMSG){
        	if(svcID == "getCoAmt"){
        		trace("getCoAmt Retrieve Success!!!");
        	}
        }

        this.form_OnLoadCompleted = function(obj,e)
        {
        	this.divHead.form.edtSrchManfArCd.set_value("aa");
        	//this.getFilterCodeDs('CS','031');

        	var jobSeCd = "CS";
        	var cmnGrpCd = SLF.lpad("031","0",3);
        	trace('SLF.app().gdsCode '+SLF.app().gdsCode.rowcount);

        	var ds = new Dataset;
        	SLF.app().gdsCode.filter("jobSeCd == '"+jobSeCd+"' && cmnGrpCd == '" + cmnGrpCd + "'");
        	ds.copyData(SLF.app().gdsCode);
        	trace('filter ds count '+ds.rowcount);
        	this.addChild('gds'+jobSeCd+'Code'+cmnGrpCd,ds);

        	this.gdsCSCode031.filter("jobSeCd == '"+jobSeCd+"' && cmnGrpCd == '" + cmnGrpCd + "'");

        	trace(this.gdsCSCode031.rowcount);
        };


        });
        
        // Regist UI Components Event
        this.on_initEvent = function()
        {
            this.addEventHandler("onload",this.form_OnLoadCompleted,this);
            this.addEventHandler("onclose",this.gfn_OnUnloadCompleted,this);
            this.grdList1.addEventHandler("onheadclick",this.fn_GridOnHeadClick,this);
            this.divTop.form.comBtnSave.addEventHandler("onclick",this.fn_ButtonOnClickHandler,this);
            this.divTop.form.comBtnClose.addEventHandler("onclick",this.fn_ButtonOnClickHandler,this);
            this.divTop.form.comBtnReset.addEventHandler("onclick",this.fn_ButtonOnClickHandler,this);
            this.divTop.form.comBtnExel.addEventHandler("onclick",this.fn_ButtonOnClickHandler,this);
            this.divTop.form.comBtnSearch.addEventHandler("onclick",this.fn_ButtonOnClickHandler,this);
            this.divTop.form.comBtnSearch.addEventHandler("oncontextmenu",this.divTop_comBtnSearch_oncontextmenu,this);
            this.Tab0.tab1.form.btnPopArForm.addEventHandler("onclick",this.fn_ButtonOnClickHandler,this);
            this.Tab0.tab1.form.btnPopDbetForm.addEventHandler("onclick",this.fn_ButtonOnClickHandler,this);
            this.Tab0.tab1.form.btnPopManfArForm.addEventHandler("onclick",this.fn_ButtonOnClickHandler,this);
            this.Tab0.tab1.form.btnPopManfDbetForm.addEventHandler("onclick",this.fn_ButtonOnClickHandler,this);
            this.Tab0.tab1.form.btnPopManfWstForm.addEventHandler("onclick",this.fn_ButtonOnClickHandler,this);
            this.Tab0.tab1.form.btnPopWstForm.addEventHandler("onclick",this.fn_ButtonOnClickHandler,this);
            this.Tab0.tab1.form.btnPopDssIdForm.addEventHandler("onclick",this.fn_ButtonOnClickHandler,this);
            this.Tab0.tab1.form.cmbWstAtbCd.addEventHandler("onitemchanged",this.Tab0_tab1_cmbWstAtbCd_OnChanged,this);
            this.divMiddle.form.btnDelete.addEventHandler("onclick",this.fn_ButtonOnClickHandler,this);
            this.divMiddle.form.btnAppend.addEventHandler("onclick",this.fn_ButtonOnClickHandler,this);
            this.divMiddle.form.btnTrn.addEventHandler("onclick",this.btn_tran_click,this);
            this.divHead.form.edtSrchArCd.addEventHandler("onkeydown",this.fn_EditOnKeyDownHandler,this);
            this.divHead.form.edtSrchArCd.addEventHandler("onkillfocus",this.fn_EditOnKillFocusHandler,this);
            this.divHead.form.btnPopSrchAr.addEventHandler("onclick",this.fn_ButtonOnClickHandler,this);
            this.divHead.form.edtSrchDbetCd.addEventHandler("onkeydown",this.fn_EditOnKeyDownHandler,this);
            this.divHead.form.edtSrchDbetCd.addEventHandler("onkillfocus",this.fn_EditOnKillFocusHandler,this);
            this.divHead.form.btnPopSrchDbet.addEventHandler("onclick",this.fn_ButtonOnClickHandler,this);
            this.divHead.form.btnPopSrchManfAr.addEventHandler("onclick",this.fn_ButtonOnClickHandler,this);
            this.divHead.form.btnPopSrchManfDbet.addEventHandler("onclick",this.fn_ButtonOnClickHandler,this);
            this.divHead.form.btnPopSrchManfWst.addEventHandler("onclick",this.fn_ButtonOnClickHandler,this);
            this.dsTncmcc041.addEventHandler("oncolumnchanged",this.dsTncmcc041_OnColumnChanged,this);
            this.dsTncmcc041.addEventHandler("onrowposchanged",this.dsTncmcc041_OnRowPosChanged,this);
        };
        this.loadIncludeScript("CMCC000103.xfdl");
        this.loadPreloadList();
        
        // Remove Reference
        obj = null;
    };
}
)();
