(function()
{
    return function()  
	{
        this.on_loadAppVariables = function()
        {		
            var obj = null;
			// global dataobject
		
            // global dataset
            obj = new Dataset("gdsMenu", this);
            obj._setContents("<ColumnInfo><Column id=\"mnuId\" type=\"STRING\" size=\"256\"/><Column id=\"jobSeCd\" type=\"STRING\" size=\"256\"/><Column id=\"mnuNm\" type=\"STRING\" size=\"256\"/><Column id=\"menuIndex\" type=\"STRING\" size=\"256\"/><Column id=\"pgmNm\" type=\"STRING\" size=\"256\"/><Column id=\"pgmUrl\" type=\"STRING\" size=\"256\"/><Column id=\"useAt\" type=\"STRING\" size=\"256\"/><Column id=\"lvl\" type=\"STRING\" size=\"256\"/></ColumnInfo>");
            this._addDataset(obj.name, obj);


            obj = new Dataset("gds_openForm", this);
            obj._setContents("<ColumnInfo><Column id=\"FORM_ID\" type=\"STRING\" size=\"256\"/><Column id=\"MENU_ID\" type=\"STRING\" size=\"256\"/><Column id=\"MENU_NAME\" type=\"STRING\" size=\"256\"/><Column id=\"FORM_URL\" type=\"STRING\" size=\"256\"/></ColumnInfo>");
            this._addDataset(obj.name, obj);


            obj = new Dataset("gdsUserInfo", this);
            obj._setContents("<ColumnInfo><Column id=\"empId\" type=\"STRING\" size=\"256\"/><Column id=\"empNm\" type=\"STRING\" size=\"256\"/><Column id=\"pwd\" type=\"INT\" size=\"256\"/></ColumnInfo>");
            this._addDataset(obj.name, obj);


            obj = new Dataset("gdsSearch", this);
            obj._setContents("<ColumnInfo><Column id=\"userId\" type=\"STRING\" size=\"256\"/></ColumnInfo>");
            this._addDataset(obj.name, obj);


            obj = new Dataset("gdsCode", this);
            obj._setContents("<ColumnInfo><Column id=\"jobSeCd\" type=\"STRING\" size=\"256\"/><Column id=\"jobSeCdNm\" type=\"STRING\" size=\"256\"/><Column id=\"cmnGrpCd\" type=\"STRING\" size=\"256\"/><Column id=\"cmnDumyCd\" type=\"STRING\" size=\"256\"/><Column id=\"cmnGrpCdNm\" type=\"STRING\" size=\"256\"/><Column id=\"cmnCd\" type=\"STRING\" size=\"256\"/><Column id=\"cmnCdNm\" type=\"STRING\" size=\"256\"/><Column id=\"refrn1\" type=\"STRING\" size=\"256\"/><Column id=\"refrn2\" type=\"STRING\" size=\"256\"/><Column id=\"refrn3\" type=\"STRING\" size=\"256\"/><Column id=\"refrn4\" type=\"STRING\" size=\"256\"/><Column id=\"refrn5\" type=\"STRING\" size=\"256\"/><Column id=\"refrn6\" type=\"STRING\" size=\"256\"/><Column id=\"refrn7\" type=\"STRING\" size=\"256\"/><Column id=\"refrn8\" type=\"STRING\" size=\"256\"/><Column id=\"refrn9\" type=\"STRING\" size=\"256\"/><Column id=\"refrn10\" type=\"STRING\" size=\"256\"/><Column id=\"sort\" type=\"STRING\" size=\"256\"/><Column id=\"useAt\" type=\"STRING\" size=\"256\"/><Column id=\"delAt\" type=\"STRING\" size=\"256\"/><Column id=\"rgsUsr\" type=\"STRING\" size=\"256\"/><Column id=\"rgsDt\" type=\"STRING\" size=\"256\"/><Column id=\"updUsr\" type=\"STRING\" size=\"256\"/><Column id=\"updDt\" type=\"STRING\" size=\"256\"/><Column id=\"rm\" type=\"STRING\" size=\"256\"/></ColumnInfo>");
            this._addDataset(obj.name, obj);
            
            // global variable
            this._addVariable("gv_variable","nexacro patform");
            this._addVariable("App_Var1","App Variable Value1");
            this._addVariable("App_Var2","App Variable Value2");
            this._addVariable("appPageReq","");
            
            obj = null;
        };
 
        // property, event, createMainFrame
        this.on_initApplication = function()
        {
            // properties
            this.set_id("Application_Desktop");
            this.set_screenid("Desktop_screen");
            this.set_licenseurl("NexacroN_client_license.xml");

            if (this._is_attach_childframe)
            	return;
        
            // frame
            var mainframe = this.createMainFrame("mainframe","0","0","1024","768",null,null,this);
            mainframe.set_showtitlebar("true");
            mainframe.set_showstatusbar("true");
            mainframe.set_titletext("반입관리시스템");
            mainframe.set_statusbarheight("25");
            mainframe.set_titlebarbuttongap("4");
            mainframe.set_titlebarbuttonsize("19 19");
            mainframe.set_titlebarheight("28");
            mainframe.on_createBodyFrame = this.mainframe_createBodyFrame;        
            // tray

        };
        
        this.loadPreloadList = function()
        {

        };
        
        this.mainframe_createBodyFrame = function()
        {
            var frame0 = new VFrameSet("VFrameSet0",null,null,null,null,null,null,this);
            frame0.set_separatesize("50,*");
            frame0.set_showtitlebar("false");
            this.addChild(frame0.name, frame0);
            this.frame=frame0;

            var frame1 = new ChildFrame("TopFrame",null,null,null,null,null,null,"FrameBase::TopFrame.xfdl",frame0);
            frame1.set_showtitlebar("false");
            frame1.set_showstatusbar("false");
            frame0.addChild(frame1.name, frame1);
            frame1.set_formurl("FrameBase::TopFrame.xfdl");


            var frame2 = new HFrameSet("HFrameSet0",null,null,null,null,null,null,frame0);
            frame2.set_separatesize("200,*");
            frame2.set_showtitlebar("false");
            frame0.addChild(frame2.name, frame2);

            var frame3 = new ChildFrame("LeftFrame",null,null,null,null,null,null,"FrameBase::LeftFrame.xfdl",frame2);
            frame3.set_showtitlebar("false");
            frame3.set_showstatusbar("false");
            frame2.addChild(frame3.name, frame3);
            frame3.set_formurl("FrameBase::LeftFrame.xfdl");


            var frame4 = new VFrameSet("VFrameSet1",null,null,null,null,null,null,frame2);
            frame4.set_separatesize("30,*");
            frame4.set_showtitlebar("false");
            frame2.addChild(frame4.name, frame4);

            var frame5 = new ChildFrame("MDIFrame",null,null,null,null,null,null,"FrameBase::MdiFrame.xfdl",frame4);
            frame5.set_showtitlebar("false");
            frame4.addChild(frame5.name, frame5);
            frame5.set_formurl("FrameBase::MdiFrame.xfdl");


            var frame6 = new FrameSet("WorkFrame",null,null,null,null,null,null,frame4);
            frame6.set_showtitlebar("false");
            frame4.addChild(frame6.name, frame6);

            var frame7 = new ChildFrame("MainForm",null,null,null,null,null,null,"FrameBase::MainForm.xfdl",frame6);
            frame7.set_showtitlebar("false");
            frame7.set_openstatus("maximize");
            frame6.addChild(frame7.name, frame7);
            frame7.set_formurl("FrameBase::MainForm.xfdl");
        };
        
        this.on_initEvent = function()
        {
            this.addEventHandler("onload",this.Application_onload,this);
        };
        
        // script Compiler
        this.registerScript("Application_Desktop.xadl", function() {
        this.av_WorkFrame = "";

        this.Application_onload = function(obj,e)
        {
        	this.fn_init(obj);
        };

        this.fn_init = function (obj)
        {
        	this.gdsMenu.filter("MENU_FLAG == '1'");
        	this.av_WorkFrame = this.mainframe.VFrameSet0.HFrameSet0.VFrameSet1.WorkFrame;
        	this.mainframe.VFrameSet0.set_visible(false);
        	var login = new ChildFrame("Login",null,null,null,null,null,null,"COMM::LOGIN.xfdl");
        	login.set_showtitlebar("false");
        	login.set_openstatus("maximize");
        	this.mainframe.addChild(login.name,login);
        	login.show();
        	this.mainframe.set_width("772px");
        	this.mainframe.set_height("400px");
        	this.mainframe.set_resizable (false);
        	var centerInfo = SLF.getCenterOfComp(772, 400);
        	this.mainframe.set_top(centerInfo.top);
        	this.mainframe.set_left(centerInfo.left);
        };


        this.App_Script = function ()
        {
        	return "App Script Desktop";
        };

        this.fnLoginCallback = function(svcID, errCD, errMSG){
        	if(errCD == 0){
        		this.mainframe.Login.destroy();
        		this.mainframe.VFrameSet0.set_visible(true);
        		this.mainframe.set_width(1208);
        		this.mainframe.set_height(720);
        		this.mainframe.set_top(0);
        		this.mainframe.set_left(0);
        		this.mainframe.set_resizable (true);

        		var ds = this.gdsSearch;
        		ds.clearData();
        		var nRow = ds.addRow();
        		ds.setColumn(nRow,'userId',this.gdsUserInfo.getColumn(0,'empId'));
        		this.transaction("getLeftMenuInfo","SvcURL::/comm/getLeftMenuInfo.nx","dsSearch=gdsSearch",
        		"mainframe.VFrameSet0.HFrameSet0.LeftFrame.form.dsLeftMenu=menuInfo mainframe.VFrameSet0.TopFrame.form.dsTopMenu=menuInfo gdsCode=gdsCode"
        		,"","fnLeftMenuCallback");

        		/*
        		if(this.gdsUserInfo){
        			var userId = this.gdsUserInfo.getColumn(0,'empId');
        			this.mainframe.VFrameSet0.HFrameSet0.LeftFrame.form.fnLeftMenuSearch(userId);
        		}
        		*/
        		trace("getLoginInfo Retrieve Success!!!");
        	}
        }

        this.fnLeftMenuCallback = function(svcID, errCD, errMSG){
        	trace('application fnLeftMenuCallback');
        	trace(this.gdsMenu.getColumn(0,'mnuNm'));
        	trace("getLeftMenuInfo Retrieve Success!!!");
        }
        });
        this.checkLicense("NexacroN_client_license.xml");
        
        this.loadPreloadList();
        this.loadCss("xcssrc::EduProject.xcss");
        this.loadIncludeScript("Application_Desktop.xadl");
    };
}
)();
