(function()
{
    return function()
    {
        if (!this._is_form)
            return;
        
        var obj = null;
        
        this.on_create = function()
        {
            this.set_name("TopFrame");
            this.set_titletext("TOP 메뉴");
            this.set_tooltiptype("default,mouseleave");
            if (Form == this.constructor)
            {
                this._setFormPosition(1022,50);
            }
            
            // Object(Dataset, ExcelExportObject) Initialize
            obj = new Dataset("dsTopMenu", this);
            obj._setContents("<ColumnInfo><Column id=\"mnuId\" type=\"STRING\" size=\"256\"/><Column id=\"jobSeCd\" type=\"STRING\" size=\"256\"/><Column id=\"mnuNm\" type=\"STRING\" size=\"256\"/><Column id=\"menuIndex\" type=\"STRING\" size=\"256\"/><Column id=\"pgmNm\" type=\"STRING\" size=\"256\"/><Column id=\"pgmUrl\" type=\"STRING\" size=\"256\"/><Column id=\"useAt\" type=\"STRING\" size=\"256\"/><Column id=\"lvl\" type=\"STRING\" size=\"256\"/></ColumnInfo>");
            this.addChild(obj.name, obj);
            
            // UI Components Initialize
            obj = new Static("Static00","201","0",null,"50","0",null,null,null,null,null,this);
            obj.set_taborder("2");
            obj.set_cssclass("sta_TF_bg");
            this.addChild(obj.name, obj);

            obj = new Menu("Menu00","231","10",null,"30","10",null,null,null,null,null,this);
            obj.set_taborder("0");
            obj.set_cssclass("mnu_TF_menu");
            obj.set_innerdataset("dsTopMenu");
            obj.set_captioncolumn("mnuNm");
            obj.set_idcolumn("mnuId");
            obj.set_levelcolumn("lvl");
            obj.set_popupitemheight("24");
            obj.set_userdatacolumn("mnuId");
            this.addChild(obj.name, obj);

            obj = new ImageViewer("ImageViewer00","20","10","160","30",null,null,null,null,null,null,this);
            obj.set_taborder("1");
            obj.set_image("URL(\"theme://images/sta_TF_logo.png\")");
            this.addChild(obj.name, obj);
            // Layout Functions
            //-- Default Layout : this
            obj = new Layout("default","",1022,50,this,function(p){});
            obj.set_mobileorientation("landscape");
            this.addLayout(obj.name, obj);
            
            // BindItem Information

            
            // TriggerItem Information

        };
        
        this.loadPreloadList = function()
        {

        };
        
        // User Script
        this.registerScript("TopFrame.xfdl", function() {

        this.Menu00_onmenuclick = function(obj,e)
        {
        //	var sID       = e.id;		    //메뉴ID Key
        	var sID       = e.userdata;		    //메뉴ID Key
        	var sName  = nexacro.getApplication().gdsMenu.lookup("mnuId", sID, "mnuNm");	//메뉴 명
        	var sURL     = nexacro.getApplication().gdsMenu.lookup("mnuId", sID, "pgmUrl");	    //화면 URL

        	nexacro.getApplication().mainframe.VFrameSet0.HFrameSet0.LeftFrame.form.fn_openForm(sID, sName, sURL);
        };

        });
        
        // Regist UI Components Event
        this.on_initEvent = function()
        {
            this.Menu00.addEventHandler("onmenuclick",this.Menu00_onmenuclick,this);
        };
        this.loadIncludeScript("TopFrame.xfdl");
        this.loadPreloadList();
        
        // Remove Reference
        obj = null;
    };
}
)();
