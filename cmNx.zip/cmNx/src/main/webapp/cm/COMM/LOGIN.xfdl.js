(function()
{
    return function()
    {
        if (!this._is_form)
            return;
        
        var obj = null;
        
        this.on_create = function()
        {
            this.set_name("LOGIN");
            this.set_titletext("New Form");
            if (Form == this.constructor)
            {
                this._setFormPosition(771,398);
            }
            
            // Object(Dataset, ExcelExportObject) Initialize
            obj = new Dataset("dsSearch", this);
            obj._setContents("<ColumnInfo><Column id=\"userId\" type=\"STRING\" size=\"256\"/><Column id=\"pwd\" type=\"STRING\" size=\"256\"/></ColumnInfo>");
            this.addChild(obj.name, obj);
            
            // UI Components Initialize
            obj = new ImageViewer("ImageViewer00","-1","-3","772","400",null,null,null,null,null,null,this);
            obj.set_taborder("0");
            obj.set_image("url(\'Images::comm/IMG_LOGIN_BG.png\')");
            this.addChild(obj.name, obj);

            obj = new Edit("edUserId","532","243","120","25",null,null,null,null,null,null,this);
            obj.set_taborder("1");
            this.addChild(obj.name, obj);

            obj = new CheckBox("chkSaveId","485","300","150","20",null,null,null,null,null,null,this);
            obj.set_taborder("2");
            obj.set_text("아이디저장");
            this.addChild(obj.name, obj);

            obj = new Button("btnLogin","660","242","65","54",null,null,null,null,null,null,this);
            obj.set_taborder("3");
            obj.set_text("로그인");
            obj.set_borderRadius("5px");
            obj.set_hotkey("RETURN");
            this.addChild(obj.name, obj);

            obj = new Button("btnExit","674","13","82","36",null,null,null,null,null,null,this);
            obj.set_taborder("4");
            obj.set_text("종료");
            obj.set_borderRadius("5px");
            this.addChild(obj.name, obj);

            obj = new MaskEdit("MaskEdPwd","532","273","120","25",null,null,null,null,null,null,this);
            obj.set_taborder("5");
            this.addChild(obj.name, obj);
            // Layout Functions
            //-- Default Layout : this
            obj = new Layout("default","",771,398,this,function(p){});
            obj.set_mobileorientation("landscape");
            this.addLayout(obj.name, obj);
            
            // BindItem Information

            
            // TriggerItem Information

        };
        
        this.loadPreloadList = function()
        {

        };
        
        // User Script
        this.registerScript("LOGIN.xfdl", function() {
        //로그인
        this.btnLogin_onclick = function(obj,e)
        {
        	if(!this.edUserId.value){
        		this.alert("ID를 입력하세요!");
        		return false;
        	}

        	var ds = SLF.app().gdsSearch;
        	ds.clearData();
        	var nRow = ds.addRow();
        	ds.setColumn(nRow,'userId',this.edUserId.value);

        	SLF.app().transaction("getLoginInfo","SvcURL::/comm/getLoginInfo.nx","dsSearch=gdsSearch","gdsUserInfo=output1","","fnLoginCallback",true,"3", false);
        };

        //종료
        this.btnExit_onclick = function(obj,e)
        {
        	SLF.app().exit();
        };

        this.LOGIN_onload = function(obj,e)
        {
        	this.edUserId.set_value("admin");
        };

        });
        
        // Regist UI Components Event
        this.on_initEvent = function()
        {
            this.addEventHandler("onload",this.LOGIN_onload,this);
            this.btnLogin.addEventHandler("onclick",this.btnLogin_onclick,this);
            this.btnExit.addEventHandler("onclick",this.btnExit_onclick,this);
        };
        this.loadIncludeScript("LOGIN.xfdl");
        this.loadPreloadList();
        
        // Remove Reference
        obj = null;
    };
}
)();
