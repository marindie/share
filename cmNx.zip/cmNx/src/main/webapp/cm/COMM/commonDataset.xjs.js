//XJS=COMM_DS.xjs
(function()
{
    return function(path)
    {
        var obj;
    
        // User Script
        this.registerScript(path, function() {
        this.getFilterCodeDs = function(jobSeCd, cmnGrpCd){
        	cmnGrpCd = Lpad(cmnGrpCd,"0",3);

        	var ds = new Dataset;
        	ds = SLF.app().gdsCode.set_filterstr("jobSeCd=='"+jobSeCd+"' && cmnGrpCd == '" + cmnGrpCd + "'");
        	this.addChild('gds'+jobSeCd+'Code'+cmnGrpCd);
        }
        });
    
        this.loadIncludeScript(path);
        
        obj = null;
    };
}
)();
